import { NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const category = searchParams.get("category") || "";

  const where: Record<string, unknown> = { active: true };
  if (category && category !== "all") {
    where.category = category;
  }

  const events = await db.libraryEvent.findMany({
    where,
    orderBy: { date: "desc" },
  });

  return NextResponse.json({
    events: events.map((e) => ({
      id: e.id,
      title: e.title,
      date: e.date,
      time: e.time,
      location: e.location,
      description: e.description,
      category: e.category,
      registrationOpen: e.registration,
      capacity: e.capacity,
      registered: e.registered,
    })),
    total: events.length,
  });
}
