import { NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const query = searchParams.get("q") || "";
  const genre = searchParams.get("genre") || "";
  const year = searchParams.get("year") || "";
  const available = searchParams.get("available") || "";

  const where: Record<string, unknown> = {};

  if (query) {
    where.OR = [
      { title: { contains: query } },
      { author: { contains: query } },
      { isbn: { contains: query } },
    ];
  }
  if (genre && genre !== "all") {
    where.genre = genre;
  }
  if (year && year !== "all") {
    where.year = parseInt(year);
  }
  if (available === "true") {
    where.available = true;
  } else if (available === "false") {
    where.available = false;
  }

  const books = await db.book.findMany({
    where,
    orderBy: { createdAt: "desc" },
  });

  return NextResponse.json({
    books: books.map((b) => ({
      id: b.id,
      title: b.title,
      author: b.author,
      genre: b.genre,
      year: b.year,
      isbn: b.isbn,
      available: b.available,
      copies: b.copies,
      featured: b.featured,
    })),
    total: books.length,
  });
}
