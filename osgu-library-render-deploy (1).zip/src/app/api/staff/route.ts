import { NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET() {
  const staff = await db.staffMember.findMany({
    where: { active: true },
    orderBy: { createdAt: "asc" },
  });

  return NextResponse.json({
    staff: staff.map((s) => ({
      id: s.id,
      name: s.name,
      role: s.role,
      email: s.email,
      phone: s.phone,
    })),
    total: staff.length,
  });
}
