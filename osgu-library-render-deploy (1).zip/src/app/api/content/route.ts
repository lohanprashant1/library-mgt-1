import { NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const section = searchParams.get("section") || "";

  if (section) {
    const content = await db.siteContent.findUnique({
      where: { section },
    });

    if (!content) {
      return NextResponse.json({ content: null });
    }

    return NextResponse.json({
      section: content.section,
      content: content.content,
    });
  }

  const allContent = await db.siteContent.findMany({
    orderBy: { section: "asc" },
  });

  return NextResponse.json({
    content: allContent.map((c) => ({
      section: c.section,
      content: c.content,
    })),
    total: allContent.length,
  });
}
