import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { verifyAdmin } from '@/lib/admin-auth';

export async function POST(request: NextRequest) {
  const admin = await verifyAdmin(request);
  if (!admin) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  await db.adminUser.update({
    where: { id: admin.id },
    data: { token: null, tokenExpiry: null },
  });

  return NextResponse.json({ success: true });
}
