import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { verifyAdmin, unauthorizedResponse } from '@/lib/admin-auth';

export async function GET(request: NextRequest) {
  const admin = await verifyAdmin(request);
  if (!admin) return unauthorizedResponse();

  const { searchParams } = new URL(request.url);
  const section = searchParams.get('section') || '';

  if (!section) {
    const allContent = await db.siteContent.findMany();
    return NextResponse.json({ content: allContent });
  }

  const content = await db.siteContent.findUnique({ where: { section } });
  if (!content) {
    return NextResponse.json({ content: null });
  }

  return NextResponse.json({ content });
}

export async function PUT(request: NextRequest) {
  const admin = await verifyAdmin(request);
  if (!admin) return unauthorizedResponse();

  try {
    const body = await request.json();
    const { section, content } = body;
    if (!section) return NextResponse.json({ error: 'Section is required' }, { status: 400 });

    const updated = await db.siteContent.upsert({
      where: { section },
      update: { content: typeof content === 'string' ? content : JSON.stringify(content) },
      create: { section, content: typeof content === 'string' ? content : JSON.stringify(content) },
    });

    return NextResponse.json(updated);
  } catch {
    return NextResponse.json({ error: 'Failed to update content' }, { status: 500 });
  }
}
