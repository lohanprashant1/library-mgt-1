import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { verifyAdmin, unauthorizedResponse } from '@/lib/admin-auth';
import { pbkdf2Sync, randomBytes } from 'crypto';

export async function PUT(request: NextRequest) {
  const admin = await verifyAdmin(request);
  if (!admin) return unauthorizedResponse();

  try {
    const { currentPassword, newPassword } = await request.json();

    if (!currentPassword || !newPassword) {
      return NextResponse.json({ error: 'Both current and new passwords are required' }, { status: 400 });
    }

    // Verify current password
    const [salt, hash] = admin.password.split(':');
    const verifyHash = pbkdf2Sync(currentPassword, salt, 10000, 64, 'sha512').toString('hex');
    if (hash !== verifyHash) {
      return NextResponse.json({ error: 'Current password is incorrect' }, { status: 401 });
    }

    // Hash new password
    const newSalt = randomBytes(16).toString('hex');
    const newHash = pbkdf2Sync(newPassword, newSalt, 10000, 64, 'sha512').toString('hex');

    await db.adminUser.update({
      where: { id: admin.id },
      data: { password: `${newSalt}:${newHash}` },
    });

    return NextResponse.json({ success: true });
  } catch {
    return NextResponse.json({ error: 'Failed to change password' }, { status: 500 });
  }
}
