import { NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET() {
  const resources = await db.digitalResource.findMany({
    where: { active: true },
    orderBy: { createdAt: "asc" },
  });

  return NextResponse.json({
    resources: resources.map((r) => ({
      id: r.id,
      name: r.name,
      description: r.description,
      category: r.category,
      url: r.url,
      icon: r.icon,
    })),
    total: resources.length,
  });
}
