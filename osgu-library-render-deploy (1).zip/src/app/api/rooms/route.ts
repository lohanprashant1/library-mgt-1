import { NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET() {
  const rooms = await db.room.findMany({
    orderBy: { createdAt: "asc" },
  });

  return NextResponse.json({
    rooms: rooms.map((r) => ({
      id: r.id,
      name: r.name,
      type: r.type,
      capacity: r.capacity,
      features: r.features,
      available: r.available,
    })),
    total: rooms.length,
  });
}
