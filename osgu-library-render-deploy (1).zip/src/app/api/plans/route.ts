import { NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET() {
  const plans = await db.membershipPlan.findMany({
    where: { active: true },
    orderBy: { createdAt: "asc" },
  });

  return NextResponse.json({
    plans: plans.map((p) => ({
      id: p.id,
      name: p.name,
      price: p.price,
      duration: p.duration,
      benefits: p.benefits,
      featured: p.featured,
    })),
    total: plans.length,
  });
}
