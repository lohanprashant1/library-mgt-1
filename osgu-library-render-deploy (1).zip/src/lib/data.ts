import { ref, get, set, update, remove } from 'firebase/database';
import { db } from './firebase';

function generateId(): string {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let r = '';
  for (let i = 0; i < 20; i++) r += chars.charAt(Math.floor(Math.random() * chars.length));
  return r;
}
function now(): string { return new Date().toISOString(); }

// ─── Auth ──────────────────────────────────────────────
async function hashPassword(password: string): Promise<string> {
  const salt = Array.from(crypto.getRandomValues(new Uint8Array(16))).map(b => b.toString(16).padStart(2, '0')).join('');
  const encoded = new TextEncoder().encode(password + salt);
  const hashBuf = await crypto.subtle.digest('SHA-512', encoded);
  const hex = Array.from(new Uint8Array(hashBuf)).map(b => b.toString(16).padStart(2, '0')).join('');
  return `${salt}:${hex}`;
}

async function verifyPassword(password: string, stored: string): Promise<boolean> {
  const [salt, hash] = stored.split(':');
  if (!salt || !hash) return false;
  const encoded = new TextEncoder().encode(password + salt);
  const hashBuf = await crypto.subtle.digest('SHA-512', encoded);
  const hex = Array.from(new Uint8Array(hashBuf)).map(b => b.toString(16).padStart(2, '0')).join('');
  return hex === hash;
}

export async function adminLogin(username: string, password: string) {
  const snap = await get(ref(db, 'admin/config'));
  if (!snap.exists()) throw new Error('Admin not set up');
  const config = snap.val();
  if (config.username !== username) throw new Error('Invalid credentials');
  const valid = await verifyPassword(password, config.password);
  if (!valid) throw new Error('Invalid credentials');
  const token = Array.from(crypto.getRandomValues(new Uint8Array(32))).map(b => b.toString(16).padStart(2, '0')).join('');
  const expiry = Date.now() + 24 * 60 * 60 * 1000;
  await update(ref(db, 'admin/config'), { token, tokenExpiry: expiry });
  return { token, name: config.name || 'Library Admin', role: config.role || 'admin', expiresAt: new Date(expiry).toISOString() };
}

export async function verifyToken(token: string) {
  const snap = await get(ref(db, 'admin/config'));
  if (!snap.exists()) return null;
  const c = snap.val();
  if (c.token !== token || Date.now() > (c.tokenExpiry || 0)) return null;
  return { valid: true, name: c.name || 'Library Admin', role: c.role || 'admin' };
}

export async function adminLogout(token: string) {
  const snap = await get(ref(db, 'admin/config'));
  if (snap.exists() && snap.val().token === token) {
    await update(ref(db, 'admin/config'), { token: null, tokenExpiry: null });
  }
  return { success: true };
}

export async function changePassword(token: string, currentPassword: string, newPassword: string) {
  const snap = await get(ref(db, 'admin/config'));
  if (!snap.exists()) throw new Error('Admin not found');
  const config = snap.val();
  if (config.token !== token) throw new Error('Unauthorized');
  const valid = await verifyPassword(currentPassword, config.password);
  if (!valid) throw new Error('Current password is wrong');
  const newHash = await hashPassword(newPassword);
  await update(ref(db, 'admin/config'), { password: newHash });
  return { success: true };
}

// ─── Generic CRUD ───────────────────────────────────────
export async function getAll(collection: string): Promise<Record<string, any>[]> {
  const snap = await get(ref(db, collection));
  if (!snap.exists()) return [];
  return Object.entries(snap.val()).map(([id, data]: [string, any]) => ({ id, ...data }));
}

export async function create(collection: string, data: Record<string, any>) {
  const id = generateId();
  const record = { ...data, id, createdAt: now(), updatedAt: now() };
  await set(ref(db, `${collection}/${id}`), record);
  return record;
}

export async function updateRecord(collection: string, id: string, data: Record<string, any>) {
  const record = { ...data, updatedAt: now() };
  await update(ref(db, `${collection}/${id}`), record);
  return { id, ...record };
}

export async function deleteRecord(collection: string, id: string) {
  await remove(ref(db, `${collection}/${id}`));
}

export async function upsertContent(section: string, content: any) {
  const snap = await get(ref(db, 'siteContent'));
  let id = '';
  if (snap.exists()) {
    const match = Object.entries(snap.val()).find(([, v]: [string, any]) => v.section === section);
    if (match) id = match[0];
  }
  const record = { section, content: typeof content === 'string' ? content : JSON.stringify(content), updatedAt: now() };
  if (id) { await update(ref(db, `siteContent/${id}`), record); }
  else { id = generateId(); await set(ref(db, `siteContent/${id}`), { ...record, id, createdAt: now() }); }
  return { id, ...record };
}

// ─── Seed ───────────────────────────────────────────────
export async function seedDatabase() {
  const snap = await get(ref(db, 'admin/config'));

  // ALWAYS force-update admin credentials to Prashant / Prashant@1
  const adminPass = await hashPassword('Prashant@1');
  const adminPayload: Record<string, any> = {
    username: 'Prashant', password: adminPass, name: 'Library Admin', role: 'admin',
  };
  if (snap.exists()) {
    const existing = snap.val();
    adminPayload.token = existing.token || null;
    adminPayload.tokenExpiry = existing.tokenExpiry || null;
    await update(ref(db, 'admin/config'), adminPayload);
  } else {
    adminPayload.token = null;
    adminPayload.tokenExpiry = null;
    await set(ref(db, 'admin/config'), adminPayload);
  }

  // Only seed collection data if database is empty (no books)
  const booksSnap = await get(ref(db, 'books'));
  if (booksSnap.exists()) {
    // Check for missing siteContent sections and add them
    const contentSnap = await get(ref(db, 'siteContent'));
    const existingSections: string[] = contentSnap.exists()
      ? Object.values(contentSnap.val()).map((v: any) => v.section) : [];

    const siteContent = [
      { section: "header", content: JSON.stringify({
        ticker: [
          "📚 New Arrivals: 2,500+ books added to our collection — Browse the Catalog now!",
          "📢 Admissions Open for 2025-26 — Visit the Admission Office for details",
          "🏆 OSGU Central Library wins \"Best Academic Library\" Award 2025",
          "⏰ Extended Hours: Library open until 11 PM during exam season (April 15 - May 10)",
          "📱 New OSGU Library Mobile App — Download now on Android & iOS"
        ],
        phone: "+91-12345-67890", email: "library@osgu.ac.in",
        libraryName: "CENTRAL LIBRARY", universityName: "Om Sterling Global University"
      }) },
      { section: "footer", content: JSON.stringify({
        description: "The OSGU Central Library is the heart of academic excellence, providing access to a vast collection of books, journals, digital resources, and research databases for the entire university community.",
        address: "OSGU Campus, NH-52, Village Brahmanwas, Distt. Hisar, Haryana - 125001",
        phone: "+91-12345-67890", email: "library@osgu.ac.in",
        hours: "Mon-Fri: 8:00 AM - 9:00 PM | Sat: 9:00 AM - 6:00 PM | Sun: 10:00 AM - 4:00 PM",
        copyright: "© 2025 OSGU Central Library, Om Sterling Global University. All rights reserved.",
        socialLinks: { facebook: "#", twitter: "#", instagram: "#", linkedin: "#", youtube: "#" }
      }) },
      { section: "about_page", content: JSON.stringify({
        mission: "To provide comprehensive library and information services that support the academic, research, and intellectual needs of the OSGU community.",
        vision: "To be a world-class academic library that fosters knowledge creation, innovation, and lifelong learning.",
        timeline: [
          { year: "2015", title: "Foundation", description: "OSGU Central Library established with 5,000 volumes." },
          { year: "2017", title: "Digital Transformation", description: "Launched digital library with e-books and online journals." },
          { year: "2018", title: "Research Support", description: "Added Scopus, Web of Science, and 20+ research databases." },
          { year: "2019", title: "Building Expansion", description: "Library expanded to 25,000 sq. ft. with new reading halls." },
          { year: "2020", title: "COVID Adaptation", description: "Launched virtual library services and remote access portal." },
          { year: "2021", title: "Smart Library", description: "Implemented RFID-based automated checkout system." },
          { year: "2022", title: "50,000 Volumes", description: "Collection reached 50,000+ books and 500+ journal subscriptions." },
          { year: "2023", title: "Innovation Hub", description: "Opened makerspace and multimedia production studio." },
          { year: "2024", title: "National Award", description: "Received 'Best Academic Library' award from NLA." }
        ],
        libraryStats: [
          { icon: "BookOpen", value: "50,000+", label: "Books & Volumes" },
          { icon: "Newspaper", value: "500+", label: "Journal Subscriptions" },
          { icon: "Monitor", value: "200+", label: "E-Resources & Databases" },
          { icon: "Users", value: "10,000+", label: "Registered Users" },
          { icon: "MapPin", value: "25,000", label: "Sq. Ft. Area" },
          { icon: "Clock", value: "90+", label: "Hours/Week" }
        ],
        policies: [
          { title: "Borrowing Policy", description: "Students: 10 books for 14 days. Faculty: 20 books for 30 days. Renewal up to 2 times." },
          { title: "Overdue Policy", description: "Fine of Rs. 5 per day per book. Maximum fine Rs. 500. Lost book: replacement cost + Rs. 100 processing fee." },
          { title: "Membership Policy", description: "OSGU students and faculty get free membership. Alumni: Rs. 500/year. External: Rs. 1,000/year." },
          { title: "Reservation Policy", description: "Reserve up to 3 books. Reserved books held for 2 days. Online reservation through library portal." },
          { title: "Library Conduct", description: "Maintain silence. No food/drinks. Mobile phones on silent. Follow dress code. Respect library property." },
          { title: "Digital Resources Policy", description: "E-resources for academic use only. No bulk downloading. Off-campus access via VPN portal." }
        ]
      }) },
      { section: "contact_page", content: JSON.stringify({
        address: "OSGU Campus, NH-52, Village Brahmanwas, Distt. Hisar, Haryana - 125001",
        phone: "+91-12345-67890", email: "library@osgu.ac.in",
        hours: [
          { day: "Monday - Friday", time: "8:00 AM - 9:00 PM" },
          { day: "Saturday", time: "9:00 AM - 6:00 PM" },
          { day: "Sunday", time: "10:00 AM - 4:00 PM" },
          { day: "Exam Season", time: "7:00 AM - 11:00 PM" },
          { day: "Holidays", time: "Closed" }
        ],
        departments: [
          { name: "Circulation Desk", phone: "+91-12345-67890", email: "circulation@osgu.ac.in" },
          { name: "Reference Section", phone: "+91-12345-67891", email: "reference@osgu.ac.in" },
          { name: "Digital Resources", phone: "+91-12345-67892", email: "digital@osgu.ac.in" },
          { name: "Technical Section", phone: "+91-12345-67893", email: "technical@osgu.ac.in" },
          { name: "Administration", phone: "+91-12345-67894", email: "admin.library@osgu.ac.in" }
        ],
        socialLinks: { facebook: "#", twitter: "#", instagram: "#", linkedin: "#", youtube: "#" }
      }) },
      { section: "research_page", content: JSON.stringify({
        citationTools: [
          { name: "Zotero", description: "Free reference management tool for collecting, organizing, and sharing research.", url: "https://www.zotero.org" },
          { name: "Mendeley", description: "Academic reference manager and PDF organizer with collaboration features.", url: "https://www.mendeley.com" },
          { name: "EndNote", description: "Professional reference management for researchers and publishers.", url: "https://endnote.com" },
          { name: "Google Scholar", description: "Search engine for scholarly literature across all disciplines.", url: "https://scholar.google.com" }
        ],
        guides: [
          { title: "Getting Started with Library Research", type: "Beginner", icon: "BookOpen" },
          { title: "Advanced Database Searching", type: "Intermediate", icon: "Search" },
          { title: "Systematic Review Methods", type: "Advanced", icon: "FileText" },
          { title: "Citation Styles (APA, MLA, Chicago)", type: "Beginner", icon: "Quote" },
          { title: "Plagiarism Prevention & Detection", type: "Beginner", icon: "Shield" },
          { title: "Open Access Publishing Guide", type: "Intermediate", icon: "Globe" }
        ],
        tutorials: [
          { title: "Library Orientation Tour", duration: "15 min", level: "Beginner" },
          { title: "How to Search Scopus Effectively", duration: "20 min", level: "Intermediate" },
          { title: "Using Turnitin for Plagiarism Check", duration: "10 min", level: "Beginner" },
          { title: "Reference Management with Zotero", duration: "25 min", level: "Intermediate" },
          { title: "Systematic Literature Review", duration: "30 min", level: "Advanced" },
          { title: "Data Visualization with Infographics", duration: "20 min", level: "Intermediate" }
        ]
      }) },
      { section: "kids_page", content: JSON.stringify({
        kidsCollections: [
          { title: "Picture Books", age: "3-6 years", count: "500+", icon: "BookOpen", color: "#C63134" },
          { title: "Early Readers", age: "5-7 years", count: "400+", icon: "BookOpen", color: "#0095EB" },
          { title: "Children's Fiction", age: "7-12 years", count: "800+", icon: "BookOpen", color: "#75B740" },
          { title: "Science & Nature", age: "6-12 years", count: "300+", icon: "BookOpen", color: "#DBAA36" },
          { title: "Comics & Graphic Novels", age: "8-14 years", count: "250+", icon: "BookOpen", color: "#E98F10" },
          { title: "Educational DVDs", age: "All ages", count: "100+", icon: "BookOpen", color: "#0E76A8" }
        ],
        teenCollections: [
          { title: "Young Adult Fiction", age: "12-18 years", count: "600+", icon: "BookOpen", color: "#C63134" },
          { title: "Study Guides & Test Prep", age: "14-18 years", count: "200+", icon: "BookOpen", color: "#0095EB" },
          { title: "Career & College Prep", age: "15-18 years", count: "150+", icon: "BookOpen", color: "#75B740" },
          { title: "Teen Non-Fiction", age: "12-18 years", count: "350+", icon: "BookOpen", color: "#DBAA36" }
        ],
        programs: [
          { title: "Summer Reading Challenge", age: "6-14 years", schedule: "May-July", icon: "Star", color: "#C63134" },
          { title: "Story Time Saturdays", age: "3-8 years", schedule: "Every Saturday 10 AM", icon: "BookOpen", color: "#0095EB" },
          { title: "Science Explorers Club", age: "8-14 years", schedule: "Wednesdays 3 PM", icon: "FlaskConical", color: "#75B740" },
          { title: "Teen Book Club", age: "12-18 years", schedule: "1st Saturday 2 PM", icon: "Users", color: "#DBAA36" },
          { title: "Homework Help Center", age: "6-16 years", schedule: "Mon-Fri 4-6 PM", icon: "GraduationCap", color: "#E98F10" },
          { title: "Arts & Crafts Workshop", age: "5-12 years", schedule: "Saturdays 2 PM", icon: "Palette", color: "#0E76A8" }
        ],
        homeworkHelp: [
          { subject: "Mathematics", grade: "Grade 1-12", icon: "Calculator" },
          { subject: "Science", grade: "Grade 1-12", icon: "FlaskConical" },
          { subject: "English & Grammar", grade: "Grade 1-10", icon: "BookOpen" },
          { subject: "Social Studies", grade: "Grade 1-10", icon: "Globe" },
          { subject: "Computer Basics", grade: "Grade 3-12", icon: "Monitor" },
          { subject: "Project Guidance", grade: "Grade 6-12", icon: "Lightbulb" }
        ]
      }) },
      { section: "account_page", content: JSON.stringify({
        welcomeTitle: "My Library Account",
        welcomeMessage: "Manage your borrowed books, reservations, and profile settings.",
        features: [
          { title: "View Borrowed Books", description: "See all books currently checked out with due dates.", icon: "BookOpen" },
          { title: "Reserve Books", description: "Place reservations on books that are currently unavailable.", icon: "Bookmark" },
          { title: "Renew Online", description: "Renew borrowed books from the comfort of your home.", icon: "RefreshCw" },
          { title: "Reading History", description: "View your past borrowed books and reading activity.", icon: "History" },
          { title: "Fine Payment", description: "Check and pay any outstanding library fines.", icon: "CreditCard" },
          { title: "Profile Settings", description: "Update your contact information and preferences.", icon: "Settings" }
        ]
      }) }
    ];
    for (const sc of siteContent) {
      if (!existingSections.includes(sc.section)) {
        const id = generateId();
        await set(ref(db, `siteContent/${id}`), { ...sc, id, createdAt: now(), updatedAt: now() });
      }
    }
    return { seeded: true, message: 'Admin credentials updated. Data already exists.' };
  }

  // Fresh seed — database is empty
  const books = [
    { title: "Introduction to Computer Science", author: "John Smith", genre: "Computer Science", year: 2023, isbn: "978-0-13-468599-1", available: true, copies: 5, featured: false },
    { title: "Advanced Mathematics for Engineers", author: "Sarah Johnson", genre: "Mathematics", year: 2022, isbn: "978-0-471-64965-2", available: true, copies: 3, featured: false },
    { title: "Modern Physics: From Atoms to Quarks", author: "Robert Williams", genre: "Physics", year: 2023, isbn: "978-0-321-66255-3", available: false, copies: 0, featured: true },
    { title: "Organic Chemistry Fundamentals", author: "Emily Davis", genre: "Chemistry", year: 2021, isbn: "978-1-118-01446-4", available: true, copies: 2, featured: false },
    { title: "Data Structures & Algorithms in Java", author: "Michael Brown", genre: "Computer Science", year: 2024, isbn: "978-0-13-257637-5", available: true, copies: 8, featured: false },
    { title: "Principles of Economics", author: "David Miller", genre: "Economics", year: 2022, isbn: "978-0-07-802173-6", available: true, copies: 4, featured: false },
    { title: "World History: A Comprehensive Guide", author: "Lisa Anderson", genre: "History", year: 2020, isbn: "978-0-393-91883-7", available: false, copies: 0, featured: false },
    { title: "Business Management Strategies", author: "James Wilson", genre: "Business", year: 2023, isbn: "978-0-13-350748-8", available: true, copies: 6, featured: true },
    { title: "Machine Learning and AI", author: "Priya Sharma", genre: "Computer Science", year: 2024, isbn: "978-1-265-04562-9", available: true, copies: 3, featured: true },
    { title: "Environmental Science Today", author: "Amanda Green", genre: "Environmental Science", year: 2023, isbn: "978-0-13-489510-10", available: true, copies: 2, featured: true },
    { title: "English Literature: A Critical History", author: "Thomas Moore", genre: "Literature", year: 2021, isbn: "978-0-393-91289-7", available: false, copies: 0, featured: false },
    { title: "Biotechnology: Principles & Applications", author: "Rajesh Kumar", genre: "Biology", year: 2024, isbn: "978-0-07-352258-11", available: true, copies: 5, featured: true },
    { title: "Digital Signal Processing", author: "Alan Oppenheim", genre: "Engineering", year: 2022, isbn: "978-0-13-214635-12", available: true, copies: 4, featured: true },
    { title: "International Law & Human Rights", author: "Maria Garcia", genre: "Law", year: 2023, isbn: "978-0-19-957285-13", available: true, copies: 2, featured: false },
    { title: "Psychology: An Introduction", author: "Richard Taylor", genre: "Psychology", year: 2021, isbn: "978-0-13-381103-14", available: true, copies: 7, featured: false },
  ];
  for (const b of books) { const id = generateId(); await set(ref(db, `books/${id}`), { ...b, id, createdAt: now(), updatedAt: now() }); }

  const events = [
    { title: "National Library Week Celebration", description: "Join us for a week-long celebration of libraries.", date: "2025-04-14", time: "10:00 AM - 4:00 PM", location: "Main Library Hall", category: "Celebration", registration: true, capacity: 200, registered: 145, active: true },
    { title: "Research Methodology Workshop", description: "Hands-on workshop on research methodologies.", date: "2025-04-18", time: "2:00 PM - 5:00 PM", location: "Seminar Room A", category: "Workshop", registration: true, capacity: 50, registered: 38, active: true },
    { title: "Author Meet & Greet: Dr. Ananya Sharma", description: "Meet bestselling author Dr. Ananya Sharma.", date: "2025-04-22", time: "11:00 AM - 1:00 PM", location: "Conference Hall", category: "Literary", registration: true, capacity: 100, registered: 72, active: true },
    { title: "Digital Literacy Bootcamp", description: "Comprehensive bootcamp covering digital research tools.", date: "2025-04-25", time: "9:00 AM - 3:00 PM", location: "Computer Lab 1", category: "Workshop", registration: true, capacity: 30, registered: 30, active: true },
    { title: "Children's Story Time", description: "Weekly story time for children aged 4-10.", date: "2025-04-20", time: "10:00 AM - 11:30 AM", location: "Children's Section", category: "Children", registration: false, capacity: 25, registered: 18, active: true },
    { title: "Database Training: Scopus & Web of Science", description: "Advanced search techniques for research databases.", date: "2025-05-02", time: "3:00 PM - 5:00 PM", location: "E-Resource Center", category: "Training", registration: true, capacity: 40, registered: 22, active: true },
    { title: "Book Club Monthly Meetup", description: "This month: The White Tiger by Aravind Adiga.", date: "2025-05-05", time: "4:00 PM - 6:00 PM", location: "Reading Lounge", category: "Literary", registration: false, capacity: 20, registered: 15, active: true },
    { title: "Open Access Week Symposium", description: "Symposium on open access publishing.", date: "2025-05-10", time: "10:00 AM - 4:00 PM", location: "Auditorium", category: "Symposium", registration: true, capacity: 150, registered: 89, active: true },
  ];
  for (const e of events) { const id = generateId(); await set(ref(db, `events/${id}`), { ...e, id, createdAt: now(), updatedAt: now() }); }

  const news = [
    { title: "Library Extends Operating Hours During Exam Season", excerpt: "The Central Library will remain open until 11 PM.", content: "Extended hours: 7 AM to 11 PM weekdays, 9 AM to 6 PM weekends.", category: "Announcement", date: "2025-04-10", active: true },
    { title: "New Digital Archives: 1,000+ Rare Manuscripts Now Online", excerpt: "Over 1,000 rare manuscripts now available online.", content: "The digitization project took 18 months and is now complete.", category: "Digital Resources", date: "2025-04-08", active: true },
    { title: "OSGU Library Wins Best Academic Library Award 2025", excerpt: "Recognized at the National Library Excellence Awards 2025.", content: "The award was presented in New Delhi by the Education Minister.", category: "Achievement", date: "2025-04-05", active: true },
    { title: "Spring Book Fair: Thousands of New Titles Added", excerpt: "Over 2,500 new titles from 50+ publishers.", content: "New arrivals are being catalogued and will be available by mid-April.", category: "Collection", date: "2025-04-01", active: true },
    { title: "Plagiarism Awareness Workshop for Research Scholars", excerpt: "Over 150 research scholars attended the workshop.", content: "Training covered Turnitin, iThenticate, and proper citation practices.", category: "Workshop", date: "2025-03-28", active: true },
    { title: "Library Launches Mobile App for Easy Access", excerpt: "The new OSGU Library mobile app is now available.", content: "Developed in-house by the IT team, available on Android and iOS.", category: "Technology", date: "2025-03-25", active: true },
  ];
  for (const n of news) { const id = generateId(); await set(ref(db, `news/${id}`), { ...n, id, createdAt: now(), updatedAt: now() }); }

  const services = [
    { name: "Book Borrowing & Returns", description: "Borrow up to 10 books for 14 days with renewal option.", icon: "BookOpen", color: "#C63134", active: true, order: 0 },
    { name: "Interlibrary Loan (ILL)", description: "Request books from partner libraries nationwide.", icon: "Globe", color: "#0095EB", active: true, order: 1 },
    { name: "Reference & Research Help", description: "Expert librarians for research consultations.", icon: "GraduationCap", color: "#75B740", active: true, order: 2 },
    { name: "Printing & Photocopying", description: "High-speed printing and scanning services.", icon: "Printer", color: "#DBAA36", active: true, order: 3 },
    { name: "Computer Lab & Internet", description: "60+ workstations and high-speed internet access.", icon: "Monitor", color: "#E98F10", active: true, order: 4 },
    { name: "Group Study Rooms", description: "Collaborative study spaces available for booking.", icon: "Users", color: "#0E76A8", active: true, order: 5 },
    { name: "Scanning & Digitization", description: "Professional scanning and digitization services.", icon: "ScanLine", color: "#8B5CF6", active: true, order: 6 },
    { name: "Accessibility Services", description: "Assistive technologies for all users.", icon: "Accessibility", color: "#EC4899", active: true, order: 7 },
  ];
  for (const s of services) { const id = generateId(); await set(ref(db, `services/${id}`), { ...s, id, createdAt: now(), updatedAt: now() }); }

  const faqs = [
    { question: "How do I get a library membership?", answer: "OSGU students and faculty automatically receive membership upon enrollment. Visit the circulation desk with your ID card.", category: "Membership", active: true, order: 0 },
    { question: "How many books can I borrow at a time?", answer: "Students can borrow up to 10 books for 14 days. Faculty members can borrow up to 20 books for 30 days.", category: "Borrowing", active: true, order: 1 },
    { question: "How do I renew my borrowed books?", answer: "Renew online through your library account or mobile app. Each book can be renewed up to 2 times.", category: "Borrowing", active: true, order: 2 },
    { question: "What are the overdue fines?", answer: "A fine of Rs. 5 per day per book. Pay at the circulation desk or through the online portal.", category: "Borrowing", active: true, order: 3 },
    { question: "How do I access e-books from home?", answer: "Use the off-campus login portal with your OSGU email credentials. Access is available 24/7.", category: "Digital Resources", active: true, order: 4 },
    { question: "What research databases are available?", answer: "Over 50 databases including Scopus, Web of Science, JSTOR, IEEE Xplore, PubMed, and more.", category: "Digital Resources", active: true, order: 5 },
    { question: "How do I reserve a study room?", answer: "Book online through the library website or mobile app, up to 7 days in advance. Free for all members.", category: "Services", active: true, order: 6 },
    { question: "What are the library's operating hours?", answer: "Monday-Friday: 8 AM - 9 PM, Saturday: 9 AM - 6 PM, Sunday: 10 AM - 4 PM.", category: "General", active: true, order: 7 },
    { question: "Can I use the library if I'm not from OSGU?", answer: "Yes! External Membership is available at Rs. 1,000 per year with borrowing privileges.", category: "Membership", active: true, order: 8 },
  ];
  for (const f of faqs) { const id = generateId(); await set(ref(db, `faqs/${id}`), { ...f, id, createdAt: now(), updatedAt: now() }); }

  const staff = [
    { name: "Dr. Meera Patel", role: "Chief Librarian", email: "meera.patel@osgu.ac.in", phone: "+91-12345-67890", active: true },
    { name: "Prof. Rajesh Verma", role: "Deputy Librarian", email: "rajesh.verma@osgu.ac.in", phone: "+91-12345-67891", active: true },
    { name: "Anita Sharma", role: "Senior Librarian", email: "anita.sharma@osgu.ac.in", phone: "+91-12345-67892", active: true },
    { name: "Vikram Singh", role: "Systems Librarian", email: "vikram.singh@osgu.ac.in", phone: "+91-12345-67893", active: true },
    { name: "Neha Gupta", role: "Reference Librarian", email: "neha.gupta@osgu.ac.in", phone: "+91-12345-67894", active: true },
    { name: "Suresh Kumar", role: "Technical Assistant", email: "suresh.kumar@osgu.ac.in", phone: "+91-12345-67895", active: true },
  ];
  for (const s of staff) { const id = generateId(); await set(ref(db, `staff/${id}`), { ...s, id, createdAt: now(), updatedAt: now() }); }

  const rooms = [
    { name: "Study Room A", type: "Study Room", capacity: 4, features: JSON.stringify(["Whiteboard", "Power Outlets", "Wi-Fi"]), available: true },
    { name: "Study Room B", type: "Study Room", capacity: 4, features: JSON.stringify(["Whiteboard", "Power Outlets", "Wi-Fi"]), available: true },
    { name: "Conference Room 1", type: "Meeting Room", capacity: 12, features: JSON.stringify(["Projector", "Whiteboard", "Video Conferencing", "Wi-Fi"]), available: true },
    { name: "Conference Room 2", type: "Meeting Room", capacity: 8, features: JSON.stringify(["Projector", "Screen", "Wi-Fi"]), available: true },
    { name: "Quiet Zone A", type: "Quiet Zone", capacity: 30, features: JSON.stringify(["Silent Area", "Individual Desks", "Power Outlets"]), available: true },
    { name: "Computer Lab", type: "Computer Lab", capacity: 40, features: JSON.stringify(["40 Workstations", "High-Speed Internet", "Printing"]), available: true },
    { name: "Media Room", type: "Multimedia", capacity: 20, features: JSON.stringify(["Large Screen", "Sound System", "Streaming"]), available: true },
    { name: "Group Study Lounge", type: "Collaborative", capacity: 24, features: JSON.stringify(["Large Tables", "Whiteboards", "Wi-Fi", "Coffee Machine"]), available: true },
  ];
  for (const r of rooms) { const id = generateId(); await set(ref(db, `rooms/${id}`), { ...r, id, createdAt: now(), updatedAt: now() }); }

  const plans = [
    { name: "Student Membership", price: "Free", duration: "Academic Year", benefits: JSON.stringify(["Borrow 10 books", "Digital resources access", "Study room booking", "Computer lab use", "Workshop access", "Interlibrary loan"]), active: true, featured: true },
    { name: "Faculty Membership", price: "Free", duration: "Employment Period", benefits: JSON.stringify(["Borrow 20 books", "Digital resources access", "Priority booking", "Research help", "ILL services", "30-day loans"]), active: true, featured: false },
    { name: "Alumni Membership", price: "Rs. 500", duration: "Per Year", benefits: JSON.stringify(["Borrow 5 books", "On-site digital access", "Study room booking", "Event access"]), active: true, featured: false },
    { name: "External Membership", price: "Rs. 1,000", duration: "Per Year", benefits: JSON.stringify(["Borrow 3 books", "On-site reading", "Reference services", "Photocopying access"]), active: true, featured: false },
  ];
  for (const p of plans) { const id = generateId(); await set(ref(db, `plans/${id}`), { ...p, id, createdAt: now(), updatedAt: now() }); }

  const resources = [
    { name: "Scopus", description: "Largest abstract and citation database of peer-reviewed literature.", category: "Research Database", url: "https://www.scopus.com", icon: "Database", active: true },
    { name: "JSTOR", description: "Digital library of academic journals, books, and primary sources.", category: "E-Journal", url: "https://www.jstor.org", icon: "Newspaper", active: true },
    { name: "IEEE Xplore", description: "Engineering and technology literature with 5 million+ documents.", category: "Research Database", url: "https://ieeexplore.ieee.org", icon: "Database", active: true },
    { name: "SpringerLink", description: "Scientific, medical, and technical research from Springer Nature.", category: "E-Journal", url: "https://link.springer.com", icon: "Newspaper", active: true },
    { name: "PubMed Central", description: "Free full-text archive of biomedical and life sciences journal literature.", category: "Research Database", url: "https://www.ncbi.nlm.nih.gov/pmc", icon: "Database", active: true },
    { name: "Web of Science", description: "Citation indexing and research discovery platform by Clarivate.", category: "Research Database", url: "https://www.webofscience.com", icon: "Database", active: true },
    { name: "EBSCOhost", description: "Multi-disciplinary full-text database with 300+ databases.", category: "E-Journal", url: "https://search.ebscohost.com", icon: "Newspaper", active: true },
    { name: "ProQuest", description: "Dissertations, theses, and scholarly content across all disciplines.", category: "E-Book", url: "https://www.proquest.com", icon: "BookOpen", active: true },
  ];
  for (const r of resources) { const id = generateId(); await set(ref(db, `resources/${id}`), { ...r, id, createdAt: now(), updatedAt: now() }); }

  const siteContent = [
    { section: "hero", content: JSON.stringify({ badge: "Welcome to OSGU Central Library", title: "Your Gateway to Knowledge & Discovery", description: "Explore our vast collection of 50,000+ books, 500+ journals, digital resources, and research databases." }) },
    { section: "stats", content: JSON.stringify([{ icon: "BookOpen", value: 50000, label: "Books & Volumes", suffix: "+" }, { icon: "Newspaper", value: 500, label: "Journals & Periodicals", suffix: "+" }, { icon: "Users", value: 10000, label: "Registered Members", suffix: "+" }, { icon: "Monitor", value: 200, label: "E-Resources & Databases", suffix: "+" }]) },
    { section: "announcements", content: JSON.stringify([{ title: "Extended Hours During Exam Season", date: "Apr 10, 2025", icon: "Clock", color: "#C63134" }, { title: "New Digital Archives: 1,000+ Rare Manuscripts", date: "Apr 8, 2025", icon: "Globe", color: "#0095EB" }, { title: "Best Academic Library Award 2025", date: "Apr 5, 2025", icon: "Star", color: "#DBAA36" }, { title: "Spring Book Fair: 2,500+ New Titles", date: "Apr 1, 2025", icon: "BookOpen", color: "#75B740" }]) },
    { section: "header", content: JSON.stringify({ ticker: ["📚 New Arrivals: 2,500+ books added to our collection — Browse the Catalog now!", "📢 Admissions Open for 2025-26 — Visit the Admission Office for details", "🏆 OSGU Central Library wins \"Best Academic Library\" Award 2025", "⏰ Extended Hours: Library open until 11 PM during exam season (April 15 - May 10)", "📱 New OSGU Library Mobile App — Download now on Android & iOS"], phone: "+91-12345-67890", email: "library@osgu.ac.in", libraryName: "CENTRAL LIBRARY", universityName: "Om Sterling Global University" }) },
    { section: "footer", content: JSON.stringify({ description: "The OSGU Central Library is the heart of academic excellence, providing access to a vast collection of books, journals, digital resources, and research databases for the entire university community.", address: "OSGU Campus, NH-52, Village Brahmanwas, Distt. Hisar, Haryana - 125001", phone: "+91-12345-67890", email: "library@osgu.ac.in", hours: "Mon-Fri: 8:00 AM - 9:00 PM | Sat: 9:00 AM - 6:00 PM | Sun: 10:00 AM - 4:00 PM", copyright: "© 2025 OSGU Central Library, Om Sterling Global University. All rights reserved.", socialLinks: { facebook: "#", twitter: "#", instagram: "#", linkedin: "#", youtube: "#" } }) },
    { section: "about_page", content: JSON.stringify({ mission: "To provide comprehensive library and information services that support the academic, research, and intellectual needs of the OSGU community.", vision: "To be a world-class academic library that fosters knowledge creation, innovation, and lifelong learning.", timeline: [{ year: "2015", title: "Foundation", description: "OSGU Central Library established with 5,000 volumes." }, { year: "2017", title: "Digital Transformation", description: "Launched digital library with e-books and online journals." }, { year: "2018", title: "Research Support", description: "Added Scopus, Web of Science, and 20+ research databases." }, { year: "2019", title: "Building Expansion", description: "Library expanded to 25,000 sq. ft. with new reading halls." }, { year: "2020", title: "COVID Adaptation", description: "Launched virtual library services and remote access portal." }, { year: "2021", title: "Smart Library", description: "Implemented RFID-based automated checkout system." }, { year: "2022", title: "50,000 Volumes", description: "Collection reached 50,000+ books and 500+ journal subscriptions." }, { year: "2023", title: "Innovation Hub", description: "Opened makerspace and multimedia production studio." }, { year: "2024", title: "National Award", description: "Received 'Best Academic Library' award from NLA." }], libraryStats: [{ icon: "BookOpen", value: "50,000+", label: "Books & Volumes" }, { icon: "Newspaper", value: "500+", label: "Journal Subscriptions" }, { icon: "Monitor", value: "200+", label: "E-Resources & Databases" }, { icon: "Users", value: "10,000+", label: "Registered Users" }, { icon: "MapPin", value: "25,000", label: "Sq. Ft. Area" }, { icon: "Clock", value: "90+", label: "Hours/Week" }], policies: [{ title: "Borrowing Policy", description: "Students: 10 books for 14 days. Faculty: 20 books for 30 days. Renewal up to 2 times." }, { title: "Overdue Policy", description: "Fine of Rs. 5 per day per book. Maximum fine Rs. 500. Lost book: replacement cost + Rs. 100 processing fee." }, { title: "Membership Policy", description: "OSGU students and faculty get free membership. Alumni: Rs. 500/year. External: Rs. 1,000/year." }, { title: "Reservation Policy", description: "Reserve up to 3 books. Reserved books held for 2 days. Online reservation through library portal." }, { title: "Library Conduct", description: "Maintain silence. No food/drinks. Mobile phones on silent. Follow dress code. Respect library property." }, { title: "Digital Resources Policy", description: "E-resources for academic use only. No bulk downloading. Off-campus access via VPN portal." }] }) },
    { section: "contact_page", content: JSON.stringify({ address: "OSGU Campus, NH-52, Village Brahmanwas, Distt. Hisar, Haryana - 125001", phone: "+91-12345-67890", email: "library@osgu.ac.in", hours: [{ day: "Monday - Friday", time: "8:00 AM - 9:00 PM" }, { day: "Saturday", time: "9:00 AM - 6:00 PM" }, { day: "Sunday", time: "10:00 AM - 4:00 PM" }, { day: "Exam Season", time: "7:00 AM - 11:00 PM" }, { day: "Holidays", time: "Closed" }], departments: [{ name: "Circulation Desk", phone: "+91-12345-67890", email: "circulation@osgu.ac.in" }, { name: "Reference Section", phone: "+91-12345-67891", email: "reference@osgu.ac.in" }, { name: "Digital Resources", phone: "+91-12345-67892", email: "digital@osgu.ac.in" }, { name: "Technical Section", phone: "+91-12345-67893", email: "technical@osgu.ac.in" }, { name: "Administration", phone: "+91-12345-67894", email: "admin.library@osgu.ac.in" }], socialLinks: { facebook: "#", twitter: "#", instagram: "#", linkedin: "#", youtube: "#" } }) },
    { section: "research_page", content: JSON.stringify({ citationTools: [{ name: "Zotero", description: "Free reference management tool.", url: "https://www.zotero.org" }, { name: "Mendeley", description: "Academic reference manager.", url: "https://www.mendeley.com" }, { name: "EndNote", description: "Professional reference management.", url: "https://endnote.com" }, { name: "Google Scholar", description: "Scholarly literature search.", url: "https://scholar.google.com" }], guides: [{ title: "Getting Started with Library Research", type: "Beginner", icon: "BookOpen" }, { title: "Advanced Database Searching", type: "Intermediate", icon: "Search" }, { title: "Systematic Review Methods", type: "Advanced", icon: "FileText" }, { title: "Citation Styles (APA, MLA, Chicago)", type: "Beginner", icon: "Quote" }, { title: "Plagiarism Prevention", type: "Beginner", icon: "Shield" }, { title: "Open Access Publishing Guide", type: "Intermediate", icon: "Globe" }], tutorials: [{ title: "Library Orientation Tour", duration: "15 min", level: "Beginner" }, { title: "How to Search Scopus Effectively", duration: "20 min", level: "Intermediate" }, { title: "Using Turnitin for Plagiarism Check", duration: "10 min", level: "Beginner" }, { title: "Reference Management with Zotero", duration: "25 min", level: "Intermediate" }, { title: "Systematic Literature Review", duration: "30 min", level: "Advanced" }, { title: "Data Visualization with Infographics", duration: "20 min", level: "Intermediate" }] }) },
    { section: "kids_page", content: JSON.stringify({ kidsCollections: [{ title: "Picture Books", age: "3-6 years", count: "500+", icon: "BookOpen", color: "#C63134" }, { title: "Early Readers", age: "5-7 years", count: "400+", icon: "BookOpen", color: "#0095EB" }, { title: "Children's Fiction", age: "7-12 years", count: "800+", icon: "BookOpen", color: "#75B740" }], teenCollections: [{ title: "Young Adult Fiction", age: "12-18 years", count: "600+", icon: "BookOpen", color: "#C63134" }], programs: [{ title: "Summer Reading Challenge", age: "6-14 years", schedule: "May-July", icon: "Star", color: "#C63134" }], homeworkHelp: [{ subject: "Mathematics", grade: "Grade 1-12", icon: "Calculator" }] }) },
    { section: "account_page", content: JSON.stringify({ welcomeTitle: "My Library Account", welcomeMessage: "Manage your borrowed books, reservations, and profile settings.", features: [{ title: "View Borrowed Books", description: "See all books currently checked out with due dates.", icon: "BookOpen" }, { title: "Reserve Books", description: "Place reservations on unavailable books.", icon: "Bookmark" }, { title: "Renew Online", description: "Renew borrowed books from home.", icon: "RefreshCw" }] }) },
  ];
  for (const sc of siteContent) { const id = generateId(); await set(ref(db, `siteContent/${id}`), { ...sc, id, createdAt: now(), updatedAt: now() }); }

  return { seeded: true, message: 'Database seeded successfully!' };
}
