"use client";

import { useState, useEffect } from "react";
import { Save, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea, ScrollBar } from "@/components/ui/scroll-area";

interface SiteSettingsProps {
  token: string;
}

// Reusable save button component
function SaveButton({
  section,
  label,
  saving,
  success,
  onClick,
}: {
  section: string;
  label: string;
  saving: Record<string, boolean>;
  success: Record<string, boolean>;
  onClick: () => void;
}) {
  return (
    <div className="flex items-center gap-2 pt-2">
      <Button
        onClick={onClick}
        disabled={saving[section]}
        className="bg-[#C63134] hover:bg-[#CC383E] text-white"
      >
        {saving[section] ? (
          <Loader2 className="w-4 h-4 animate-spin mr-1.5" />
        ) : (
          <Save className="w-4 h-4 mr-1.5" />
        )}
        Save {label}
      </Button>
      {success[section] && (
        <span className="text-sm text-[#75B740] font-medium">Saved!</span>
      )}
    </div>
  );
}

export default function SiteSettings({ token }: SiteSettingsProps) {
  // Hero state
  const [hero, setHero] = useState({ badge: "", title: "", description: "" });

  // Stats state (raw JSON string)
  const [stats, setStats] = useState<string>("");

  // Announcements state (raw JSON string)
  const [announcements, setAnnouncements] = useState<string>("");

  // Header state
  const [header, setHeader] = useState({
    libraryName: "",
    universityName: "",
    phone: "",
    email: "",
  });
  const [headerTickerJson, setHeaderTickerJson] = useState<string>("[]");

  // Footer state
  const [footer, setFooter] = useState({
    description: "",
    address: "",
    phone: "",
    email: "",
    hours: "",
    copyright: "",
  });
  const [footerSocialJson, setFooterSocialJson] = useState<string>("{}");

  // About page state
  const [about, setAbout] = useState({
    mission: "",
    vision: "",
  });
  const [aboutTimelineJson, setAboutTimelineJson] = useState<string>("[]");
  const [aboutPoliciesJson, setAboutPoliciesJson] = useState<string>("[]");

  // Contact page state
  const [contact, setContact] = useState({
    address: "",
    phone: "",
    email: "",
  });
  const [contactHoursJson, setContactHoursJson] = useState<string>("[]");
  const [contactDeptsJson, setContactDeptsJson] = useState<string>("[]");

  // Research page state
  const [researchCitationJson, setResearchCitationJson] = useState<string>("[]");
  const [researchGuidesJson, setResearchGuidesJson] = useState<string>("[]");

  // Kids page state
  const [kidsCollectionsJson, setKidsCollectionsJson] = useState<string>("[]");
  const [kidsProgramsJson, setKidsProgramsJson] = useState<string>("[]");

  // Account page state
  const [account, setAccount] = useState({
    welcomeTitle: "",
    welcomeMessage: "",
  });
  const [accountFeaturesJson, setAccountFeaturesJson] = useState<string>("[]");

  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState<Record<string, boolean>>({});
  const [success, setSuccess] = useState<Record<string, boolean>>({});

  useEffect(() => {
    const fetchContent = async () => {
      setLoading(true);
      try {
        const res = await fetch("/api/admin/content", {
          headers: { Authorization: `Bearer ${token}` },
        });
        const data = await res.json();
        const contentList = data.content || [];

        const find = (section: string) =>
          contentList.find((c: { section: string }) => c.section === section);

        // Hero
        const heroItem = find("hero");
        if (heroItem) {
          const parsed = JSON.parse(heroItem.content);
          setHero({
            badge: parsed.badge || "",
            title: parsed.title || "",
            description: parsed.description || "",
          });
        }

        // Stats
        const statsItem = find("stats");
        if (statsItem) setStats(statsItem.content);

        // Announcements
        const annItem = find("announcements");
        if (annItem) setAnnouncements(annItem.content);

        // Header
        const headerItem = find("header");
        if (headerItem) {
          const parsed = JSON.parse(headerItem.content);
          setHeader({
            libraryName: parsed.libraryName || "",
            universityName: parsed.universityName || "",
            phone: parsed.phone || "",
            email: parsed.email || "",
          });
          setHeaderTickerJson(JSON.stringify(parsed.ticker || [], null, 2));
        }

        // Footer
        const footerItem = find("footer");
        if (footerItem) {
          const parsed = JSON.parse(footerItem.content);
          setFooter({
            description: parsed.description || "",
            address: parsed.address || "",
            phone: parsed.phone || "",
            email: parsed.email || "",
            hours: parsed.hours || "",
            copyright: parsed.copyright || "",
          });
          setFooterSocialJson(JSON.stringify(parsed.socialLinks || {}, null, 2));
        }

        // About page
        const aboutItem = find("about_page");
        if (aboutItem) {
          const parsed = JSON.parse(aboutItem.content);
          setAbout({
            mission: parsed.mission || "",
            vision: parsed.vision || "",
          });
          setAboutTimelineJson(JSON.stringify(parsed.timeline || [], null, 2));
          setAboutPoliciesJson(JSON.stringify(parsed.policies || [], null, 2));
        }

        // Contact page
        const contactItem = find("contact_page");
        if (contactItem) {
          const parsed = JSON.parse(contactItem.content);
          setContact({
            address: parsed.address || "",
            phone: parsed.phone || "",
            email: parsed.email || "",
          });
          setContactHoursJson(JSON.stringify(parsed.hours || [], null, 2));
          setContactDeptsJson(JSON.stringify(parsed.departments || [], null, 2));
        }

        // Research page
        const researchItem = find("research_page");
        if (researchItem) {
          const parsed = JSON.parse(researchItem.content);
          setResearchCitationJson(JSON.stringify(parsed.citationTools || [], null, 2));
          setResearchGuidesJson(JSON.stringify(parsed.guides || [], null, 2));
        }

        // Kids page
        const kidsItem = find("kids_page");
        if (kidsItem) {
          const parsed = JSON.parse(kidsItem.content);
          setKidsCollectionsJson(JSON.stringify(parsed.kidsCollections || [], null, 2));
          setKidsProgramsJson(JSON.stringify(parsed.programs || [], null, 2));
        }

        // Account page
        const accountItem = find("account_page");
        if (accountItem) {
          const parsed = JSON.parse(accountItem.content);
          setAccount({
            welcomeTitle: parsed.welcomeTitle || "",
            welcomeMessage: parsed.welcomeMessage || "",
          });
          setAccountFeaturesJson(JSON.stringify(parsed.features || [], null, 2));
        }
      } catch {
        // ignore fetch errors
      } finally {
        setLoading(false);
      }
    };
    fetchContent();
  }, [token]);

  const saveSection = async (section: string, content: string) => {
    setSaving((prev) => ({ ...prev, [section]: true }));
    setSuccess((prev) => ({ ...prev, [section]: false }));

    try {
      const res = await fetch("/api/admin/content", {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ section, content }),
      });

      if (res.ok) {
        setSuccess((prev) => ({ ...prev, [section]: true }));
        setTimeout(() => setSuccess((prev) => ({ ...prev, [section]: false })), 2000);
      }
    } catch {
      // ignore
    } finally {
      setSaving((prev) => ({ ...prev, [section]: false }));
    }
  };

  // Save handlers for each section
  const saveHero = () => saveSection("hero", JSON.stringify(hero));
  const saveStats = () => saveSection("stats", stats);
  const saveAnnouncements = () => saveSection("announcements", announcements);

  const saveHeader = () => {
    try {
      const ticker = JSON.parse(headerTickerJson);
      saveSection("header", JSON.stringify({ ...header, ticker }));
    } catch {
      alert("Invalid JSON in Ticker Messages");
    }
  };

  const saveFooter = () => {
    try {
      const socialLinks = JSON.parse(footerSocialJson);
      saveSection("footer", JSON.stringify({ ...footer, socialLinks }));
    } catch {
      alert("Invalid JSON in Social Links");
    }
  };

  const saveAbout = () => {
    try {
      const timeline = JSON.parse(aboutTimelineJson);
      const policies = JSON.parse(aboutPoliciesJson);
      saveSection("about_page", JSON.stringify({ ...about, timeline, policies }));
    } catch {
      alert("Invalid JSON in Timeline or Policies");
    }
  };

  const saveContact = () => {
    try {
      const hours = JSON.parse(contactHoursJson);
      const departments = JSON.parse(contactDeptsJson);
      saveSection("contact_page", JSON.stringify({ ...contact, hours, departments }));
    } catch {
      alert("Invalid JSON in Hours or Departments");
    }
  };

  const saveResearch = () => {
    try {
      const citationTools = JSON.parse(researchCitationJson);
      const guides = JSON.parse(researchGuidesJson);
      saveSection("research_page", JSON.stringify({ citationTools, guides }));
    } catch {
      alert("Invalid JSON in Citation Tools or Guides");
    }
  };

  const saveKids = () => {
    try {
      const kidsCollections = JSON.parse(kidsCollectionsJson);
      const programs = JSON.parse(kidsProgramsJson);
      saveSection("kids_page", JSON.stringify({ kidsCollections, programs }));
    } catch {
      alert("Invalid JSON in Kids Collections or Programs");
    }
  };

  const saveAccount = () => {
    try {
      const features = JSON.parse(accountFeaturesJson);
      saveSection("account_page", JSON.stringify({ ...account, features }));
    } catch {
      alert("Invalid JSON in Features");
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="w-6 h-6 text-[#C63134] animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-lg font-bold text-[#16191A]">Site Settings</h2>
        <p className="text-sm text-[#666]">
          Manage all site content sections — hero, header, footer, pages, and more
        </p>
      </div>

      <Tabs defaultValue="hero">
        <ScrollArea className="w-full">
          <TabsList className="inline-flex h-auto gap-1 bg-[#F5F5F5] p-1 rounded-lg">
            <TabsTrigger value="hero" className="text-xs sm:text-sm px-3 py-1.5 data-[state=active]:bg-[#C63134] data-[state=active]:text-white">
              Hero
            </TabsTrigger>
            <TabsTrigger value="stats" className="text-xs sm:text-sm px-3 py-1.5 data-[state=active]:bg-[#C63134] data-[state=active]:text-white">
              Stats
            </TabsTrigger>
            <TabsTrigger value="announcements" className="text-xs sm:text-sm px-3 py-1.5 data-[state=active]:bg-[#C63134] data-[state=active]:text-white">
              Announcements
            </TabsTrigger>
            <TabsTrigger value="header" className="text-xs sm:text-sm px-3 py-1.5 data-[state=active]:bg-[#C63134] data-[state=active]:text-white">
              Header
            </TabsTrigger>
            <TabsTrigger value="footer" className="text-xs sm:text-sm px-3 py-1.5 data-[state=active]:bg-[#C63134] data-[state=active]:text-white">
              Footer
            </TabsTrigger>
            <TabsTrigger value="about" className="text-xs sm:text-sm px-3 py-1.5 data-[state=active]:bg-[#C63134] data-[state=active]:text-white">
              About Page
            </TabsTrigger>
            <TabsTrigger value="contact" className="text-xs sm:text-sm px-3 py-1.5 data-[state=active]:bg-[#C63134] data-[state=active]:text-white">
              Contact Page
            </TabsTrigger>
            <TabsTrigger value="research" className="text-xs sm:text-sm px-3 py-1.5 data-[state=active]:bg-[#C63134] data-[state=active]:text-white">
              Research Page
            </TabsTrigger>
            <TabsTrigger value="kids" className="text-xs sm:text-sm px-3 py-1.5 data-[state=active]:bg-[#C63134] data-[state=active]:text-white">
              Kids Page
            </TabsTrigger>
            <TabsTrigger value="account" className="text-xs sm:text-sm px-3 py-1.5 data-[state=active]:bg-[#C63134] data-[state=active]:text-white">
              Account Page
            </TabsTrigger>
          </TabsList>
          <ScrollBar orientation="horizontal" />
        </ScrollArea>

        {/* ========== HERO ========== */}
        <TabsContent value="hero">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Hero Section</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label className="text-sm font-medium text-[#333] mb-1.5 block">Badge Text</Label>
                <Input
                  value={hero.badge}
                  onChange={(e) => setHero((prev) => ({ ...prev, badge: e.target.value }))}
                />
              </div>
              <div>
                <Label className="text-sm font-medium text-[#333] mb-1.5 block">Title</Label>
                <Input
                  value={hero.title}
                  onChange={(e) => setHero((prev) => ({ ...prev, title: e.target.value }))}
                />
              </div>
              <div>
                <Label className="text-sm font-medium text-[#333] mb-1.5 block">Description</Label>
                <Textarea
                  value={hero.description}
                  onChange={(e) => setHero((prev) => ({ ...prev, description: e.target.value }))}
                  rows={3}
                />
              </div>
              <SaveButton section="hero" label="Hero" saving={saving} success={success} onClick={saveHero} />
            </CardContent>
          </Card>
        </TabsContent>

        {/* ========== STATS ========== */}
        <TabsContent value="stats">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Statistics</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label className="text-sm font-medium text-[#333] mb-1.5 block">Stats JSON</Label>
                <Textarea
                  value={stats}
                  onChange={(e) => setStats(e.target.value)}
                  rows={10}
                  className="font-mono text-xs"
                />
                <p className="text-xs text-[#999] mt-1">Format: JSON array of {`{ icon, value, label, suffix }`}</p>
              </div>
              <SaveButton section="stats" label="Stats" saving={saving} success={success} onClick={saveStats} />
            </CardContent>
          </Card>
        </TabsContent>

        {/* ========== ANNOUNCEMENTS ========== */}
        <TabsContent value="announcements">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Announcements</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label className="text-sm font-medium text-[#333] mb-1.5 block">Announcements JSON</Label>
                <Textarea
                  value={announcements}
                  onChange={(e) => setAnnouncements(e.target.value)}
                  rows={12}
                  className="font-mono text-xs"
                />
                <p className="text-xs text-[#999] mt-1">Format: JSON array of {`{ title, date, icon, color }`}</p>
              </div>
              <SaveButton section="announcements" label="Announcements" saving={saving} success={success} onClick={saveAnnouncements} />
            </CardContent>
          </Card>
        </TabsContent>

        {/* ========== HEADER ========== */}
        <TabsContent value="header">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Header Settings</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label className="text-sm font-medium text-[#333] mb-1.5 block">Library Name</Label>
                <Input
                  value={header.libraryName}
                  onChange={(e) => setHeader((prev) => ({ ...prev, libraryName: e.target.value }))}
                />
              </div>
              <div>
                <Label className="text-sm font-medium text-[#333] mb-1.5 block">University Name</Label>
                <Input
                  value={header.universityName}
                  onChange={(e) => setHeader((prev) => ({ ...prev, universityName: e.target.value }))}
                />
              </div>
              <div>
                <Label className="text-sm font-medium text-[#333] mb-1.5 block">Phone</Label>
                <Input
                  value={header.phone}
                  onChange={(e) => setHeader((prev) => ({ ...prev, phone: e.target.value }))}
                />
              </div>
              <div>
                <Label className="text-sm font-medium text-[#333] mb-1.5 block">Email</Label>
                <Input
                  value={header.email}
                  onChange={(e) => setHeader((prev) => ({ ...prev, email: e.target.value }))}
                />
              </div>
              <div>
                <Label className="text-sm font-medium text-[#333] mb-1.5 block">Ticker Messages (JSON)</Label>
                <Textarea
                  value={headerTickerJson}
                  onChange={(e) => setHeaderTickerJson(e.target.value)}
                  rows={6}
                  className="font-mono text-xs"
                />
                <p className="text-xs text-[#999] mt-1">Format: JSON array of strings</p>
              </div>
              <SaveButton section="header" label="Header" saving={saving} success={success} onClick={saveHeader} />
            </CardContent>
          </Card>
        </TabsContent>

        {/* ========== FOOTER ========== */}
        <TabsContent value="footer">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Footer Settings</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label className="text-sm font-medium text-[#333] mb-1.5 block">Description</Label>
                <Textarea
                  value={footer.description}
                  onChange={(e) => setFooter((prev) => ({ ...prev, description: e.target.value }))}
                  rows={3}
                />
              </div>
              <div>
                <Label className="text-sm font-medium text-[#333] mb-1.5 block">Address</Label>
                <Input
                  value={footer.address}
                  onChange={(e) => setFooter((prev) => ({ ...prev, address: e.target.value }))}
                />
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <Label className="text-sm font-medium text-[#333] mb-1.5 block">Phone</Label>
                  <Input
                    value={footer.phone}
                    onChange={(e) => setFooter((prev) => ({ ...prev, phone: e.target.value }))}
                  />
                </div>
                <div>
                  <Label className="text-sm font-medium text-[#333] mb-1.5 block">Email</Label>
                  <Input
                    value={footer.email}
                    onChange={(e) => setFooter((prev) => ({ ...prev, email: e.target.value }))}
                  />
                </div>
              </div>
              <div>
                <Label className="text-sm font-medium text-[#333] mb-1.5 block">Hours</Label>
                <Input
                  value={footer.hours}
                  onChange={(e) => setFooter((prev) => ({ ...prev, hours: e.target.value }))}
                />
              </div>
              <div>
                <Label className="text-sm font-medium text-[#333] mb-1.5 block">Copyright</Label>
                <Input
                  value={footer.copyright}
                  onChange={(e) => setFooter((prev) => ({ ...prev, copyright: e.target.value }))}
                />
              </div>
              <div>
                <Label className="text-sm font-medium text-[#333] mb-1.5 block">Social Links (JSON)</Label>
                <Textarea
                  value={footerSocialJson}
                  onChange={(e) => setFooterSocialJson(e.target.value)}
                  rows={6}
                  className="font-mono text-xs"
                />
                <p className="text-xs text-[#999] mt-1">Format: JSON object with keys: facebook, twitter, instagram, linkedin, youtube</p>
              </div>
              <SaveButton section="footer" label="Footer" saving={saving} success={success} onClick={saveFooter} />
            </CardContent>
          </Card>
        </TabsContent>

        {/* ========== ABOUT PAGE ========== */}
        <TabsContent value="about">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">About Page Settings</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label className="text-sm font-medium text-[#333] mb-1.5 block">Mission Statement</Label>
                <Textarea
                  value={about.mission}
                  onChange={(e) => setAbout((prev) => ({ ...prev, mission: e.target.value }))}
                  rows={3}
                />
              </div>
              <div>
                <Label className="text-sm font-medium text-[#333] mb-1.5 block">Vision Statement</Label>
                <Textarea
                  value={about.vision}
                  onChange={(e) => setAbout((prev) => ({ ...prev, vision: e.target.value }))}
                  rows={3}
                />
              </div>
              <div>
                <Label className="text-sm font-medium text-[#333] mb-1.5 block">Timeline (JSON)</Label>
                <Textarea
                  value={aboutTimelineJson}
                  onChange={(e) => setAboutTimelineJson(e.target.value)}
                  rows={10}
                  className="font-mono text-xs"
                />
                <p className="text-xs text-[#999] mt-1">Format: JSON array of {`{ year, title, description }`}</p>
              </div>
              <div>
                <Label className="text-sm font-medium text-[#333] mb-1.5 block">Policies (JSON)</Label>
                <Textarea
                  value={aboutPoliciesJson}
                  onChange={(e) => setAboutPoliciesJson(e.target.value)}
                  rows={8}
                  className="font-mono text-xs"
                />
                <p className="text-xs text-[#999] mt-1">Format: JSON array of {`{ title, description }`}</p>
              </div>
              <SaveButton section="about_page" label="About Page" saving={saving} success={success} onClick={saveAbout} />
            </CardContent>
          </Card>
        </TabsContent>

        {/* ========== CONTACT PAGE ========== */}
        <TabsContent value="contact">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Contact Page Settings</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label className="text-sm font-medium text-[#333] mb-1.5 block">Address</Label>
                <Input
                  value={contact.address}
                  onChange={(e) => setContact((prev) => ({ ...prev, address: e.target.value }))}
                />
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <Label className="text-sm font-medium text-[#333] mb-1.5 block">Phone</Label>
                  <Input
                    value={contact.phone}
                    onChange={(e) => setContact((prev) => ({ ...prev, phone: e.target.value }))}
                  />
                </div>
                <div>
                  <Label className="text-sm font-medium text-[#333] mb-1.5 block">Email</Label>
                  <Input
                    value={contact.email}
                    onChange={(e) => setContact((prev) => ({ ...prev, email: e.target.value }))}
                  />
                </div>
              </div>
              <div>
                <Label className="text-sm font-medium text-[#333] mb-1.5 block">Hours (JSON)</Label>
                <Textarea
                  value={contactHoursJson}
                  onChange={(e) => setContactHoursJson(e.target.value)}
                  rows={6}
                  className="font-mono text-xs"
                />
                <p className="text-xs text-[#999] mt-1">Format: JSON array of {`{ day, time }`}</p>
              </div>
              <div>
                <Label className="text-sm font-medium text-[#333] mb-1.5 block">Departments (JSON)</Label>
                <Textarea
                  value={contactDeptsJson}
                  onChange={(e) => setContactDeptsJson(e.target.value)}
                  rows={8}
                  className="font-mono text-xs"
                />
                <p className="text-xs text-[#999] mt-1">Format: JSON array of {`{ name, phone, email }`}</p>
              </div>
              <SaveButton section="contact_page" label="Contact Page" saving={saving} success={success} onClick={saveContact} />
            </CardContent>
          </Card>
        </TabsContent>

        {/* ========== RESEARCH PAGE ========== */}
        <TabsContent value="research">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Research Page Settings</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label className="text-sm font-medium text-[#333] mb-1.5 block">Citation Tools (JSON)</Label>
                <Textarea
                  value={researchCitationJson}
                  onChange={(e) => setResearchCitationJson(e.target.value)}
                  rows={10}
                  className="font-mono text-xs"
                />
                <p className="text-xs text-[#999] mt-1">Format: JSON array of {`{ name, description, url }`}</p>
              </div>
              <div>
                <Label className="text-sm font-medium text-[#333] mb-1.5 block">Research Guides (JSON)</Label>
                <Textarea
                  value={researchGuidesJson}
                  onChange={(e) => setResearchGuidesJson(e.target.value)}
                  rows={8}
                  className="font-mono text-xs"
                />
                <p className="text-xs text-[#999] mt-1">Format: JSON array of {`{ title, type }`}</p>
              </div>
              <SaveButton section="research_page" label="Research Page" saving={saving} success={success} onClick={saveResearch} />
            </CardContent>
          </Card>
        </TabsContent>

        {/* ========== KIDS PAGE ========== */}
        <TabsContent value="kids">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Kids & Teens Page Settings</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label className="text-sm font-medium text-[#333] mb-1.5 block">Kids Collections (JSON)</Label>
                <Textarea
                  value={kidsCollectionsJson}
                  onChange={(e) => setKidsCollectionsJson(e.target.value)}
                  rows={8}
                  className="font-mono text-xs"
                />
                <p className="text-xs text-[#999] mt-1">Format: JSON array of {`{ title, age, count, color }`}</p>
              </div>
              <div>
                <Label className="text-sm font-medium text-[#333] mb-1.5 block">Programs (JSON)</Label>
                <Textarea
                  value={kidsProgramsJson}
                  onChange={(e) => setKidsProgramsJson(e.target.value)}
                  rows={8}
                  className="font-mono text-xs"
                />
                <p className="text-xs text-[#999] mt-1">Format: JSON array of {`{ title, age, schedule, color }`}</p>
              </div>
              <SaveButton section="kids_page" label="Kids Page" saving={saving} success={success} onClick={saveKids} />
            </CardContent>
          </Card>
        </TabsContent>

        {/* ========== ACCOUNT PAGE ========== */}
        <TabsContent value="account">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Account Page Settings</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label className="text-sm font-medium text-[#333] mb-1.5 block">Welcome Title</Label>
                <Input
                  value={account.welcomeTitle}
                  onChange={(e) => setAccount((prev) => ({ ...prev, welcomeTitle: e.target.value }))}
                />
              </div>
              <div>
                <Label className="text-sm font-medium text-[#333] mb-1.5 block">Welcome Message</Label>
                <Textarea
                  value={account.welcomeMessage}
                  onChange={(e) => setAccount((prev) => ({ ...prev, welcomeMessage: e.target.value }))}
                  rows={3}
                />
              </div>
              <div>
                <Label className="text-sm font-medium text-[#333] mb-1.5 block">Features (JSON)</Label>
                <Textarea
                  value={accountFeaturesJson}
                  onChange={(e) => setAccountFeaturesJson(e.target.value)}
                  rows={10}
                  className="font-mono text-xs"
                />
                <p className="text-xs text-[#999] mt-1">Format: JSON array of {`{ title, description }`}</p>
              </div>
              <SaveButton section="account_page" label="Account Page" saving={saving} success={success} onClick={saveAccount} />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
