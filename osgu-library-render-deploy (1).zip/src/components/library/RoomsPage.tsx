"use client";

import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  DoorOpen,
  Users,
  Monitor,
  MapPin,
  Check,
} from "lucide-react";

interface Room {
  id: string;
  name: string;
  type: string;
  capacity: number;
  features: string;
  available: boolean;
}

const ROOM_COLORS = [
  "#C63134", "#0095EB", "#75B740", "#DBAA36",
  "#E98F10", "#0E76A8", "#8B5CF6", "#EC4899",
];

const TIME_SLOTS = [
  "8:00 AM", "9:00 AM", "10:00 AM", "11:00 AM", "12:00 PM",
  "1:00 PM", "2:00 PM", "3:00 PM", "4:00 PM", "5:00 PM",
  "6:00 PM", "7:00 PM", "8:00 PM",
];

const DEFAULT_ROOMS: Room[] = [
  { id: "1", name: "Study Room A", type: "Study Room", capacity: 4, features: JSON.stringify(["Whiteboard", "Power Outlets", "Wi-Fi", "Natural Light"]), available: true },
  { id: "2", name: "Study Room B", type: "Study Room", capacity: 4, features: JSON.stringify(["Whiteboard", "Power Outlets", "Wi-Fi"]), available: true },
  { id: "3", name: "Conference Room 1", type: "Meeting Room", capacity: 12, features: JSON.stringify(["Projector", "Whiteboard", "Video Conferencing", "Wi-Fi", "Air Conditioning"]), available: true },
  { id: "4", name: "Conference Room 2", type: "Meeting Room", capacity: 8, features: JSON.stringify(["Projector", "Screen", "Wi-Fi", "Air Conditioning"]), available: true },
  { id: "5", name: "Quiet Zone A", type: "Quiet Zone", capacity: 30, features: JSON.stringify(["Silent Area", "Individual Desks", "Power Outlets", "Reading Lamps"]), available: true },
  { id: "6", name: "Computer Lab", type: "Computer Lab", capacity: 40, features: JSON.stringify(["40 Workstations", "High-Speed Internet", "Printing", "Scanning", "Software Suite"]), available: true },
  { id: "7", name: "Media Room", type: "Multimedia", capacity: 20, features: JSON.stringify(["Large Screen", "Sound System", "DVD/Blu-ray", "Streaming", "Comfortable Seating"]), available: true },
  { id: "8", name: "Group Study Lounge", type: "Collaborative", capacity: 24, features: JSON.stringify(["Large Tables", "Whiteboards", "Wi-Fi", "Coffee Machine", "Flexible Seating"]), available: true },
];

const ROOM_DESCRIPTIONS: Record<string, string> = {
  "Study Room": "Quiet study room perfect for focused individual or small group study sessions.",
  "Meeting Room": "Professional meeting room equipped with AV equipment for presentations and meetings.",
  "Quiet Zone": "Designated silent study area for deep concentration. No talking or phone calls allowed.",
  "Computer Lab": "Fully equipped computer lab with workstations, printing, and academic software.",
  "Multimedia": "Multimedia room for watching educational films, lectures, and presentations.",
  "Collaborative": "Open collaborative space with large tables for group projects and discussions.",
};

export default function RoomsPage() {
  const [rooms, setRooms] = useState<Room[]>(DEFAULT_ROOMS);
  const [loading, setLoading] = useState(true);
  const [selectedRoom, setSelectedRoom] = useState<Room | null>(null);
  const [selectedDate, setSelectedDate] = useState("2025-04-15");
  const [selectedSlots, setSelectedSlots] = useState<string[]>([]);

  useEffect(() => {
    fetch("/api/rooms")
      .then((res) => res.json())
      .then((data) => {
        if (data.rooms?.length > 0) {
          setRooms(data.rooms);
        }
      })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  const toggleSlot = (slot: string) => {
    setSelectedSlots((prev) =>
      prev.includes(slot) ? prev.filter((s) => s !== slot) : [...prev, slot]
    );
  };

  const roomTypes = ["All", "Study Room", "Meeting Room", "Quiet Zone", "Computer Lab", "Multimedia", "Collaborative"];

  const parseFeatures = (features: string): string[] => {
    try {
      return JSON.parse(features);
    } catch {
      return features.split(",").map((f) => f.trim());
    }
  };

  if (loading) return <div className="py-20 text-center text-[#666]">Loading...</div>;

  return (
    <div>
      {/* Hero */}
      <section className="bg-[#191919] py-12 sm:py-16">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <Badge className="bg-[#0E76A8] text-white mb-3">
            <DoorOpen className="w-3.5 h-3.5 mr-1.5" />
            Rooms & Spaces
          </Badge>
          <h1 className="text-3xl sm:text-4xl font-bold text-white mb-3">
            Book a <span className="text-[#0E76A8]">Study Space</span>
          </h1>
          <p className="text-[#CCCCCC] max-w-2xl mx-auto">
            Reserve study rooms, meeting spaces, computer labs, and collaborative areas.
            Find the perfect space for your needs.
          </p>
        </div>
      </section>

      <section className="bg-[#FCFCFC] py-12 sm:py-16">
        <div className="max-w-7xl mx-auto px-4">
          {/* Filter */}
          <div className="flex flex-wrap items-center gap-3 mb-8">
            <span className="text-sm font-medium text-[#333]">Filter by type:</span>
            {roomTypes.map((type) => (
              <Badge
                key={type}
                className="cursor-pointer hover:bg-[#C63134] hover:text-white transition-colors"
                variant="secondary"
              >
                {type}
              </Badge>
            ))}
          </div>

          {/* Room Grid */}
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {rooms.map((room, idx) => {
              const features = parseFeatures(room.features);
              const color = ROOM_COLORS[idx % ROOM_COLORS.length];
              const description = ROOM_DESCRIPTIONS[room.type] || "A comfortable study space for your needs.";
              return (
                <Card
                  key={room.id}
                  className={`osgu-card border cursor-pointer ${
                    selectedRoom?.id === room.id
                      ? "ring-2 ring-[#C63134] border-transparent"
                      : "border-[#EBEBEB]"
                  }`}
                  onClick={() => setSelectedRoom(room)}
                >
                  <div className="h-1.5" style={{ backgroundColor: color }} />
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between mb-2">
                      <Badge
                        className="text-xs"
                        style={{ backgroundColor: color, color: "white" }}
                      >
                        {room.type}
                      </Badge>
                      <Badge
                        className={`text-xs ${room.available ? "bg-[#75B740] text-white" : "bg-[#999] text-white"}`}
                      >
                        {room.available ? "Available" : "Occupied"}
                      </Badge>
                    </div>
                    <h3 className="font-bold text-[#16191A] mb-1">{room.name}</h3>
                    <p className="text-xs text-[#666] mb-3 line-clamp-2">{description}</p>
                    <div className="flex items-center gap-1.5 text-sm text-[#666] mb-3">
                      <Users className="w-4 h-4" />
                      <span>{room.capacity} capacity</span>
                    </div>
                    <div className="flex flex-wrap gap-1">
                      {features.slice(0, 3).map((f, j) => (
                        <span key={j} className="text-[10px] px-1.5 py-0.5 bg-[#F1F1F1] text-[#666] rounded">
                          {f}
                        </span>
                      ))}
                      {features.length > 3 && (
                        <span className="text-[10px] px-1.5 py-0.5 bg-[#F1F1F1] text-[#666] rounded">
                          +{features.length - 3} more
                        </span>
                      )}
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          {/* Booking Panel */}
          {selectedRoom && (
            <Card className="mt-8 border-[#EBEBEB]">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="text-xl">{selectedRoom.name}</CardTitle>
                    <p className="text-sm text-[#666] mt-1">{ROOM_DESCRIPTIONS[selectedRoom.type] || "A comfortable study space."}</p>
                  </div>
                  <Button variant="outline" onClick={() => { setSelectedRoom(null); setSelectedSlots([]); }}>
                    Close
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                {/* Room Details */}
                <div className="flex flex-wrap gap-4 mb-6 p-4 bg-[#F1F1F1] rounded-lg">
                  <div className="flex items-center gap-2 text-sm">
                    <Users className="w-4 h-4 text-[#C63134]" />
                    <span>Capacity: {selectedRoom.capacity} people</span>
                  </div>
                  {parseFeatures(selectedRoom.features).map((f, i) => (
                    <div key={i} className="flex items-center gap-1.5 text-xs text-[#666]">
                      <Check className="w-3.5 h-3.5 text-[#75B740]" />
                      {f}
                    </div>
                  ))}
                </div>

                {/* Date Selection */}
                <div className="mb-4">
                  <label className="text-sm font-medium text-[#333] mb-2 block">Select Date</label>
                  <Input
                    type="date"
                    value={selectedDate}
                    onChange={(e) => setSelectedDate(e.target.value)}
                    className="max-w-xs"
                  />
                </div>

                {/* Time Slots */}
                <div className="mb-6">
                  <label className="text-sm font-medium text-[#333] mb-3 block">Select Time Slots</label>
                  <div className="grid grid-cols-4 sm:grid-cols-7 gap-2">
                    {TIME_SLOTS.map((slot) => {
                      const isSelected = selectedSlots.includes(slot);
                      const isOccupied = slot === "10:00 AM" || slot === "2:00 PM"; // Mock occupied
                      return (
                        <button
                          key={slot}
                          disabled={isOccupied}
                          onClick={() => toggleSlot(slot)}
                          className={`py-2 px-2 text-xs rounded-lg text-center transition-colors ${
                            isOccupied
                              ? "bg-[#EBEBEB] text-[#999] cursor-not-allowed line-through"
                              : isSelected
                              ? "bg-[#C63134] text-white"
                              : "bg-[#F1F1F1] text-[#333] hover:bg-[#C63134]/10 hover:text-[#C63134]"
                          }`}
                        >
                          {slot}
                        </button>
                      );
                    })}
                  </div>
                  <div className="flex gap-4 mt-2 text-xs text-[#999]">
                    <span className="flex items-center gap-1">
                      <div className="w-3 h-3 bg-[#C63134] rounded" /> Selected
                    </span>
                    <span className="flex items-center gap-1">
                      <div className="w-3 h-3 bg-[#EBEBEB] rounded" /> Occupied
                    </span>
                    <span className="flex items-center gap-1">
                      <div className="w-3 h-3 bg-[#F1F1F1] rounded border border-[#EBEBEB]" /> Available
                    </span>
                  </div>
                </div>

                {/* Book Button */}
                <Button
                  className="bg-[#C63134] hover:bg-[#CC383E] text-white"
                  disabled={selectedSlots.length === 0}
                >
                  <DoorOpen className="w-4 h-4 mr-2" />
                  Book {selectedSlots.length > 0 ? `${selectedSlots.length} slot(s)` : ""}
                </Button>
              </CardContent>
            </Card>
          )}
        </div>
      </section>
    </div>
  );
}
