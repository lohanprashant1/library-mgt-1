"use client";

import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import {
  HelpCircle,
  Search,
  BookOpen,
  ChevronRight,
  Video,
  FileText,
  Lightbulb,
  MessageSquare,
  Phone,
  Mail,
  ExternalLink,
  CircleHelp,
  CreditCard,
  Clock,
  BookMarked,
  Shield,
  Monitor,
  Users,
} from "lucide-react";

const DEFAULT_FAQS = [
  {
    q: "How do I get a library membership?",
    a: "OSGU students and faculty automatically receive library membership upon enrollment/employment. Visit the circulation desk with your OSGU ID card to activate your account. External members can register online or at the library with valid ID proof and the applicable fee.",
    category: "Membership",
  },
  {
    q: "How many books can I borrow at a time?",
    a: "Students can borrow up to 10 books for 14 days. Faculty members can borrow up to 20 books for 30 days.",
    category: "Borrowing",
  },
  {
    q: "What are the library's operating hours?",
    a: "Regular hours: Mon-Fri 8:00 AM - 9:00 PM, Sat 9:00 AM - 6:00 PM, Sun 10:00 AM - 4:00 PM.",
    category: "General",
  },
];

const CATEGORY_COLORS: Record<string, string> = {
  Borrowing: "#C63134",
  "Digital Resources": "#0095EB",
  Membership: "#DBAA36",
  Services: "#E98F10",
  General: "#75B740",
};

const FAQ_CATEGORY_ICONS: Record<string, any> = {
  All: HelpCircle,
  Borrowing: BookOpen,
  "Digital Resources": Monitor,
  Membership: CreditCard,
  Services: Shield,
  General: CircleHelp,
};

const HOW_TO_GUIDES = [
  { title: "How to Search the Catalog", desc: "Step-by-step guide to finding books in our catalog", icon: Search, color: "#C63134" },
  { title: "How to Use Databases", desc: "Navigate research databases like Scopus and JSTOR", icon: Monitor, color: "#0095EB" },
  { title: "How to Manage Citations", desc: "Setting up Zotero or Mendeley for your research", icon: FileText, color: "#75B740" },
  { title: "How to Book a Room", desc: "Reserve study rooms and collaborative spaces", icon: Users, color: "#DBAA36" },
];

const VIDEO_TUTORIALS = [
  { title: "Getting Started with the Library", duration: "5 min", color: "#C63134" },
  { title: "Using the Self-Checkout Kiosk", duration: "3 min", color: "#0095EB" },
  { title: "Searching Scopus Effectively", duration: "8 min", color: "#75B740" },
  { title: "Setting Up Zotero", duration: "10 min", color: "#DBAA36" },
  { title: "Library Mobile App Tour", duration: "4 min", color: "#E98F10" },
];

export default function FAQPage() {
  const [searchQuery, setSearchQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState("All");
  const [faqs, setFaqs] = useState(DEFAULT_FAQS);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("/api/faqs")
      .then((res) => res.json())
      .then((data) => {
        if (data.faqs?.length > 0) {
          setFaqs(data.faqs.map((f: any) => ({
            q: f.question,
            a: f.answer,
            category: f.category,
          })));
        }
      })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <div className="py-20 text-center text-[#666]">Loading...</div>;

  // Build category list from fetched FAQs
  const categoryMap: Record<string, number> = {};
  faqs.forEach((f) => {
    categoryMap[f.category] = (categoryMap[f.category] || 0) + 1;
  });
  const faqCategories = [
    { label: "All", icon: HelpCircle, count: faqs.length },
    ...Object.entries(categoryMap).map(([label, count]) => ({
      label,
      icon: FAQ_CATEGORY_ICONS[label] || CircleHelp,
      count,
    })),
  ];

  const filteredFaqs = faqs.filter((faq) => {
    const matchesSearch =
      searchQuery === "" ||
      faq.q.toLowerCase().includes(searchQuery.toLowerCase()) ||
      faq.a.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = activeCategory === "All" || faq.category === activeCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div>
      {/* Hero */}
      <section className="bg-[#191919] py-12 sm:py-16">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <Badge className="bg-[#75B740] text-white mb-3">
            <HelpCircle className="w-3.5 h-3.5 mr-1.5" />
            FAQ & Help
          </Badge>
          <h1 className="text-3xl sm:text-4xl font-bold text-white mb-3">
            How Can We <span className="text-[#75B740]">Help</span>?
          </h1>
          <p className="text-[#CCCCCC] max-w-2xl mx-auto">
            Find answers to common questions, access guides, tutorials, and get the support you need.
          </p>
        </div>
      </section>

      {/* Search & Categories */}
      <section className="bg-[#FCFCFC] py-8 border-b border-[#EBEBEB]">
        <div className="max-w-7xl mx-auto px-4">
          <div className="max-w-lg mx-auto mb-6">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#999]" />
              <Input
                placeholder="Search FAQs..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>
          <div className="flex flex-wrap gap-2 justify-center">
            {faqCategories.map((cat) => (
              <Button
                key={cat.label}
                variant={activeCategory === cat.label ? "default" : "outline"}
                size="sm"
                onClick={() => setActiveCategory(cat.label)}
                className={
                  activeCategory === cat.label
                    ? "bg-[#C63134] hover:bg-[#CC383E] text-white"
                    : "border-[#EBEBEB] text-[#666]"
                }
              >
                <cat.icon className="w-3.5 h-3.5 mr-1.5" />
                {cat.label} ({cat.count})
              </Button>
            ))}
          </div>
        </div>
      </section>

      {/* FAQs */}
      <section className="bg-[#FCFCFC] py-8 sm:py-12">
        <div className="max-w-3xl mx-auto px-4">
          <h2 className="text-xl font-bold text-[#16191A] mb-6">
            Frequently Asked Questions ({filteredFaqs.length})
          </h2>

          {filteredFaqs.length === 0 ? (
            <div className="text-center py-12">
              <HelpCircle className="w-16 h-16 text-[#EBEBEB] mx-auto mb-3" />
              <p className="text-[#666]">No FAQs match your search. Try a different keyword.</p>
            </div>
          ) : (
            <Accordion type="single" collapsible className="w-full">
              {filteredFaqs.map((faq, i) => (
                <AccordionItem key={i} value={`faq-${i}`} className="border-[#EBEBEB]">
                  <AccordionTrigger className="text-left text-sm font-medium text-[#16191A] hover:text-[#C63134]">
                    <div className="flex items-center gap-2 pr-4">
                      <Badge
                        className="text-[10px] px-1.5 py-0 flex-shrink-0"
                        style={{
                          backgroundColor: `${CATEGORY_COLORS[faq.category] || "#75B740"}15`,
                          color: CATEGORY_COLORS[faq.category] || "#75B740",
                        }}
                      >
                        {faq.category}
                      </Badge>
                      {faq.q}
                    </div>
                  </AccordionTrigger>
                  <AccordionContent className="text-sm text-[#666] leading-relaxed">
                    {faq.a}
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          )}
        </div>
      </section>

      {/* How-To Guides & Video Tutorials */}
      <section className="bg-[#F1F1F1] py-12 sm:py-16">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-8">
            {/* How-To Guides */}
            <div>
              <h2 className="text-xl font-bold text-[#16191A] mb-4 flex items-center gap-2">
                <FileText className="w-5 h-5 text-[#C63134]" />
                How-To Guides
              </h2>
              <div className="space-y-3">
                {HOW_TO_GUIDES.map((guide, i) => (
                  <Card key={i} className="osgu-card border-[#EBEBEB] bg-white cursor-pointer">
                    <CardContent className="p-4 flex items-center gap-3">
                      <div
                        className="w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0"
                        style={{ backgroundColor: `${guide.color}15` }}
                      >
                        <guide.icon className="w-5 h-5" style={{ color: guide.color }} />
                      </div>
                      <div className="flex-1">
                        <h3 className="font-medium text-sm text-[#16191A]">{guide.title}</h3>
                        <p className="text-xs text-[#666]">{guide.desc}</p>
                      </div>
                      <ChevronRight className="w-4 h-4 text-[#999]" />
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>

            {/* Video Tutorials */}
            <div>
              <h2 className="text-xl font-bold text-[#16191A] mb-4 flex items-center gap-2">
                <Video className="w-5 h-5 text-[#0095EB]" />
                Video Tutorials
              </h2>
              <div className="space-y-3">
                {VIDEO_TUTORIALS.map((vid, i) => (
                  <Card key={i} className="osgu-card border-[#EBEBEB] bg-white cursor-pointer">
                    <CardContent className="p-4 flex items-center gap-3">
                      <div
                        className="w-16 h-10 rounded-lg flex items-center justify-center flex-shrink-0"
                        style={{ backgroundColor: `${vid.color}15` }}
                      >
                        <Video className="w-5 h-5" style={{ color: vid.color }} />
                      </div>
                      <div className="flex-1">
                        <h3 className="font-medium text-sm text-[#16191A]">{vid.title}</h3>
                        <p className="text-xs text-[#999]">{vid.duration}</p>
                      </div>
                      <ChevronRight className="w-4 h-4 text-[#999]" />
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Support */}
      <section className="bg-[#222222] py-12 sm:py-16">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <h2 className="text-2xl font-bold text-white mb-3">
            Still Need Help?
          </h2>
          <p className="text-[#CCCCCC] mb-8 max-w-xl mx-auto">
            Our library staff is always happy to assist you. Reach out through any of these channels.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            {[
              { icon: Phone, label: "Call Us", detail: "+91-12345-67890", color: "#C63134" },
              { icon: Mail, label: "Email Us", detail: "library@osgu.ac.in", color: "#0095EB" },
              { icon: MessageSquare, label: "Live Chat", detail: "Available 9 AM - 6 PM", color: "#75B740" },
            ].map((item, i) => (
              <Card key={i} className="bg-[#292B33] border-[#333] min-w-[200px]">
                <CardContent className="p-5 text-center">
                  <div
                    className="w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-3"
                    style={{ backgroundColor: `${item.color}20` }}
                  >
                    <item.icon className="w-6 h-6" style={{ color: item.color }} />
                  </div>
                  <h3 className="font-semibold text-white text-sm">{item.label}</h3>
                  <p className="text-xs text-[#CCCCCC] mt-1">{item.detail}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
