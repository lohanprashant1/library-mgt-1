import { PrismaClient } from "@prisma/client";
import { createHash, randomBytes, pbkdf2Sync } from "crypto";

const db = new PrismaClient();

function hashPassword(password: string): string {
  const salt = randomBytes(16).toString("hex");
  const hash = pbkdf2Sync(password, salt, 10000, 64, "sha512").toString("hex");
  return `${salt}:${hash}`;
}

function verifyPassword(password: string, stored: string): boolean {
  const [salt, hash] = stored.split(":");
  const verify = pbkdf2Sync(password, salt, 10000, 64, "sha512").toString("hex");
  return hash === verify;
}

async function main() {
  console.log("🌱 Seeding database...");

  // 1. Create admin user
  const adminPassword = hashPassword("Prashant@1");
  const admin = await db.adminUser.upsert({
    where: { username: "Prashant" },
    update: {},
    create: {
      username: "Prashant",
      password: adminPassword,
      name: "Library Admin",
      role: "admin",
    },
  });
  console.log(`✅ Admin user created: ${admin.username}`);

  // 2. Seed books
  const booksData = [
    { title: "Introduction to Computer Science", author: "John Smith", genre: "Computer Science", year: 2023, isbn: "978-0-13-468599-1", available: true, copies: 5, featured: false },
    { title: "Advanced Mathematics for Engineers", author: "Sarah Johnson", genre: "Mathematics", year: 2022, isbn: "978-0-471-64965-2", available: true, copies: 3, featured: false },
    { title: "Modern Physics: From Atoms to Quarks", author: "Robert Williams", genre: "Physics", year: 2023, isbn: "978-0-321-66255-3", available: false, copies: 0, featured: true },
    { title: "Organic Chemistry Fundamentals", author: "Emily Davis", genre: "Chemistry", year: 2021, isbn: "978-1-118-01446-4", available: true, copies: 2, featured: false },
    { title: "Data Structures & Algorithms in Java", author: "Michael Brown", genre: "Computer Science", year: 2024, isbn: "978-0-13-257637-5", available: true, copies: 8, featured: false },
    { title: "Principles of Economics", author: "David Miller", genre: "Economics", year: 2022, isbn: "978-0-07-802173-6", available: true, copies: 4, featured: false },
    { title: "World History: A Comprehensive Guide", author: "Lisa Anderson", genre: "History", year: 2020, isbn: "978-0-393-91883-7", available: false, copies: 0, featured: false },
    { title: "Business Management Strategies", author: "James Wilson", genre: "Business", year: 2023, isbn: "978-0-13-350748-8", available: true, copies: 6, featured: true },
    { title: "Machine Learning and AI", author: "Priya Sharma", genre: "Computer Science", year: 2024, isbn: "978-1-265-04562-9", available: true, copies: 3, featured: true },
    { title: "Environmental Science Today", author: "Amanda Green", genre: "Environmental Science", year: 2023, isbn: "978-0-13-489510-10", available: true, copies: 2, featured: true },
    { title: "English Literature: A Critical History", author: "Thomas Moore", genre: "Literature", year: 2021, isbn: "978-0-393-91289-7", available: false, copies: 0, featured: false },
    { title: "Biotechnology: Principles & Applications", author: "Rajesh Kumar", genre: "Biology", year: 2024, isbn: "978-0-07-352258-11", available: true, copies: 5, featured: true },
    { title: "Digital Signal Processing", author: "Alan Oppenheim", genre: "Engineering", year: 2022, isbn: "978-0-13-214635-12", available: true, copies: 4, featured: true },
    { title: "International Law & Human Rights", author: "Maria Garcia", genre: "Law", year: 2023, isbn: "978-0-19-957285-13", available: true, copies: 2, featured: false },
    { title: "Psychology: An Introduction", author: "Richard Taylor", genre: "Psychology", year: 2021, isbn: "978-0-13-381103-14", available: true, copies: 7, featured: false },
  ];

  for (const book of booksData) {
    await db.book.upsert({
      where: { isbn: book.isbn },
      update: book,
      create: book,
    });
  }
  console.log(`✅ ${booksData.length} books seeded`);

  // 3. Seed events
  const eventsData = [
    { title: "National Library Week Celebration", description: "Join us for a week-long celebration of libraries with book readings, workshops, and cultural programs.", date: "2025-04-14", time: "10:00 AM - 4:00 PM", location: "Main Library Hall", category: "Celebration", registration: true, capacity: 200, registered: 145, active: true },
    { title: "Research Methodology Workshop", description: "Hands-on workshop on research methodologies for postgraduate students.", date: "2025-04-18", time: "2:00 PM - 5:00 PM", location: "Seminar Room A", category: "Workshop", registration: true, capacity: 50, registered: 38, active: true },
    { title: "Author Meet & Greet: Dr. Ananya Sharma", description: "Meet bestselling author Dr. Ananya Sharma as she discusses her latest book.", date: "2025-04-22", time: "11:00 AM - 1:00 PM", location: "Conference Hall", category: "Literary", registration: true, capacity: 100, registered: 72, active: true },
    { title: "Digital Literacy Bootcamp", description: "A comprehensive bootcamp covering digital research tools and online database navigation.", date: "2025-04-25", time: "9:00 AM - 3:00 PM", location: "Computer Lab 1", category: "Workshop", registration: true, capacity: 30, registered: 30, active: true },
    { title: "Children's Story Time", description: "Weekly story time for children aged 4-10. This week's theme: Adventures in Space.", date: "2025-04-20", time: "10:00 AM - 11:30 AM", location: "Children's Section", category: "Children", registration: false, capacity: 25, registered: 18, active: true },
    { title: "Database Training: Scopus & Web of Science", description: "Learn advanced search techniques for Scopus and Web of Science databases.", date: "2025-05-02", time: "3:00 PM - 5:00 PM", location: "E-Resource Center", category: "Training", registration: true, capacity: 40, registered: 22, active: true },
    { title: "Book Club Monthly Meetup", description: "This month's selection: The White Tiger by Aravind Adiga.", date: "2025-05-05", time: "4:00 PM - 6:00 PM", location: "Reading Lounge", category: "Literary", registration: false, capacity: 20, registered: 15, active: true },
    { title: "Open Access Week Symposium", description: "A symposium on open access publishing and institutional repositories.", date: "2025-05-10", time: "10:00 AM - 4:00 PM", location: "Auditorium", category: "Symposium", registration: true, capacity: 150, registered: 89, active: true },
  ];

  for (const event of eventsData) {
    await db.libraryEvent.create({
      data: event,
    });
  }
  console.log(`✅ ${eventsData.length} events seeded`);

  // 4. Seed news
  const newsData = [
    { title: "Library Extends Operating Hours During Exam Season", excerpt: "The Central Library will remain open until 11 PM during the upcoming examination period.", content: "Extended hours will be from 7 AM to 11 PM on weekdays and 8 AM to 9 PM on weekends.", category: "Announcement", date: "2025-04-10", active: true },
    { title: "New Digital Archives: 1,000+ Rare Manuscripts Now Online", excerpt: "Over 1,000 rare manuscripts and historical documents are now available online.", content: "The digitization project took over 18 months to complete with support from the National Manuscript Mission.", category: "Digital Resources", date: "2025-04-08", active: true },
    { title: "OSGU Library Wins Best Academic Library Award 2025", excerpt: "The library has been recognized as the Best Academic Library at the National Library Excellence Awards 2025.", content: "The award was presented at a ceremony in New Delhi.", category: "Achievement", date: "2025-04-05", active: true },
    { title: "Spring Book Fair: Thousands of New Titles Added", excerpt: "Over 2,500 new titles added to our collection from 50+ publishers.", content: "New arrivals are being catalogued and will be available by mid-April.", category: "Collection", date: "2025-04-01", active: true },
    { title: "Plagiarism Awareness Workshop for Research Scholars", excerpt: "Over 150 research scholars attended the plagiarism awareness workshop.", content: "The workshop included hands-on training with Turnitin and iThenticate software.", category: "Workshop", date: "2025-03-28", active: true },
    { title: "Library Launches Mobile App for Easy Access", excerpt: "The new OSGU Library mobile app is now available for download.", content: "The app was developed in-house by the university's IT team.", category: "Technology", date: "2025-03-25", active: true },
  ];

  for (const news of newsData) {
    await db.newsArticle.create({ data: news });
  }
  console.log(`✅ ${newsData.length} news articles seeded`);

  // 5. Seed services
  const servicesData = [
    { name: "Book Borrowing & Returns", description: "Borrow up to 10 books for 14 days. Renew online up to 2 times.", icon: "BookOpen", color: "#C63134", active: true, order: 0 },
    { name: "Interlibrary Loan (ILL)", description: "Request books and articles from partner libraries across India.", icon: "Globe", color: "#0095EB", active: true, order: 1 },
    { name: "Reference & Research Help", description: "Expert librarians available for research consultations and citation guidance.", icon: "GraduationCap", color: "#75B740", active: true, order: 2 },
    { name: "Printing & Photocopying", description: "High-speed printing, photocopying, and scanning services at affordable rates.", icon: "Printer", color: "#DBAA36", active: true, order: 3 },
    { name: "Computer Lab & Internet", description: "Fully equipped computer lab with 60+ workstations and high-speed internet.", icon: "Monitor", color: "#E98F10", active: true, order: 4 },
    { name: "Group Study Rooms", description: "Reserve collaborative study spaces with whiteboards and projectors.", icon: "Users", color: "#0E76A8", active: true, order: 5 },
    { name: "Scanning & Digitization", description: "Professional document scanning and digitization services.", icon: "ScanLine", color: "#8B5CF6", active: true, order: 6 },
    { name: "Accessibility Services", description: "Assistive technologies and specialized equipment for all users.", icon: "Accessibility", color: "#EC4899", active: true, order: 7 },
  ];

  for (const svc of servicesData) {
    await db.service.create({ data: svc });
  }
  console.log(`✅ ${servicesData.length} services seeded`);

  // 6. Seed FAQs
  const faqsData = [
    { question: "How do I get a library membership?", answer: "OSGU students and faculty automatically receive library membership upon enrollment. Visit the circulation desk with your OSGU ID card to activate your account.", category: "Membership", active: true, order: 0 },
    { question: "How many books can I borrow at a time?", answer: "Students can borrow up to 10 books for 14 days. Faculty members can borrow up to 20 books for 30 days.", category: "Borrowing", active: true, order: 1 },
    { question: "How do I renew my borrowed books?", answer: "You can renew books online through your library account or the mobile app. Each book can be renewed up to 2 times.", category: "Borrowing", active: true, order: 2 },
    { question: "What are the overdue fines?", answer: "A fine of ₹5 per day per book is charged for overdue items. Fines can be paid at the circulation desk or through the online portal.", category: "Borrowing", active: true, order: 3 },
    { question: "How do I access e-books from home?", answer: "Use the off-campus login portal on the library website and authenticate with your OSGU email credentials.", category: "Digital Resources", active: true, order: 4 },
    { question: "What research databases are available?", answer: "We subscribe to over 50 research databases including Scopus, Web of Science, JSTOR, IEEE Xplore, and PubMed Central.", category: "Digital Resources", active: true, order: 5 },
    { question: "Can I download e-books for offline reading?", answer: "Yes, many platforms support offline reading through their dedicated apps.", category: "Digital Resources", active: true, order: 6 },
    { question: "How do I reserve a study room?", answer: "Study rooms can be booked online through the library website or mobile app. Rooms can be booked up to 7 days in advance.", category: "Services", active: true, order: 7 },
    { question: "Does the library offer printing and photocopying?", answer: "Yes! We offer both black-and-white (₹1/page) and color printing (₹5/page).", category: "Services", active: true, order: 8 },
    { question: "What are the library's operating hours?", answer: "Regular hours: Mon-Fri 8:00 AM - 9:00 PM, Sat 9:00 AM - 6:00 PM, Sun 10:00 AM - 4:00 PM.", category: "General", active: true, order: 9 },
    { question: "Can I use the library if I'm not from OSGU?", answer: "Yes! External Membership is available at ₹1,000 per year.", category: "Membership", active: true, order: 10 },
    { question: "What should I do if I lose a library book?", answer: "Report the loss immediately at the circulation desk. You'll need to pay the replacement cost plus a ₹100 processing fee.", category: "Borrowing", active: true, order: 11 },
  ];

  for (const faq of faqsData) {
    await db.fAQ.create({ data: faq });
  }
  console.log(`✅ ${faqsData.length} FAQs seeded`);

  // 7. Seed staff
  const staffData = [
    { name: "Dr. Meera Patel", role: "Chief Librarian", email: "meera.patel@osgu.ac.in", phone: "+91-12345-67890", active: true },
    { name: "Prof. Rajesh Verma", role: "Deputy Librarian", email: "rajesh.verma@osgu.ac.in", phone: "+91-12345-67891", active: true },
    { name: "Anita Sharma", role: "Senior Librarian", email: "anita.sharma@osgu.ac.in", phone: "+91-12345-67892", active: true },
    { name: "Vikram Singh", role: "Systems Librarian", email: "vikram.singh@osgu.ac.in", phone: "+91-12345-67893", active: true },
    { name: "Neha Gupta", role: "Reference Librarian", email: "neha.gupta@osgu.ac.in", phone: "+91-12345-67894", active: true },
    { name: "Suresh Kumar", role: "Technical Assistant", email: "suresh.kumar@osgu.ac.in", phone: "+91-12345-67895", active: true },
  ];

  for (const staff of staffData) {
    await db.staffMember.create({ data: staff });
  }
  console.log(`✅ ${staffData.length} staff members seeded`);

  // 8. Seed rooms
  const roomsData = [
    { name: "Study Room A", type: "Study Room", capacity: 4, features: JSON.stringify(["Whiteboard", "Power Outlets", "Wi-Fi", "Natural Light"]), available: true },
    { name: "Study Room B", type: "Study Room", capacity: 4, features: JSON.stringify(["Whiteboard", "Power Outlets", "Wi-Fi"]), available: true },
    { name: "Conference Room 1", type: "Meeting Room", capacity: 12, features: JSON.stringify(["Projector", "Whiteboard", "Video Conferencing", "Wi-Fi", "Air Conditioning"]), available: true },
    { name: "Conference Room 2", type: "Meeting Room", capacity: 8, features: JSON.stringify(["Projector", "Screen", "Wi-Fi", "Air Conditioning"]), available: true },
    { name: "Quiet Zone A", type: "Quiet Zone", capacity: 30, features: JSON.stringify(["Silent Area", "Individual Desks", "Power Outlets", "Reading Lamps"]), available: true },
    { name: "Computer Lab", type: "Computer Lab", capacity: 40, features: JSON.stringify(["40 Workstations", "High-Speed Internet", "Printing", "Scanning", "Software Suite"]), available: true },
    { name: "Media Room", type: "Multimedia", capacity: 20, features: JSON.stringify(["Large Screen", "Sound System", "DVD/Blu-ray", "Streaming", "Comfortable Seating"]), available: true },
    { name: "Group Study Lounge", type: "Collaborative", capacity: 24, features: JSON.stringify(["Large Tables", "Whiteboards", "Wi-Fi", "Coffee Machine", "Flexible Seating"]), available: true },
  ];

  for (const room of roomsData) {
    await db.room.create({ data: room });
  }
  console.log(`✅ ${roomsData.length} rooms seeded`);

  // 9. Seed membership plans
  const plansData = [
    { name: "Student Membership", price: "Free", duration: "Academic Year", benefits: JSON.stringify(["Borrow up to 10 books", "Access all digital resources", "Book study rooms (free)", "Computer lab access", "Attend workshops & events", "Interlibrary loan services", "Printing at student rates", "Mobile app access"]), active: true, featured: true },
    { name: "Faculty Membership", price: "Free", duration: "Employment Period", benefits: JSON.stringify(["Borrow up to 20 books", "Access all digital resources", "Priority room booking", "Research consultation", "ILL services (free)", "Extended loan periods (30 days)", "Document delivery service", "Proxy borrowing privileges"]), active: true, featured: false },
    { name: "Alumni Membership", price: "₹500", duration: "Per Year", benefits: JSON.stringify(["Borrow up to 5 books", "On-site digital resource access", "Study room booking", "Computer lab access", "Attend public events", "Newsletter subscription"]), active: true, featured: false },
    { name: "External Membership", price: "₹1,000", duration: "Per Year", benefits: JSON.stringify(["Borrow up to 3 books", "On-site reading access", "Reference services", "Photocopying services", "Attend public events", "Newsletter subscription"]), active: true, featured: false },
  ];

  for (const plan of plansData) {
    await db.membershipPlan.create({ data: plan });
  }
  console.log(`✅ ${plansData.length} membership plans seeded`);

  // 10. Seed digital resources
  const resourcesData = [
    { name: "Scopus", description: "Largest abstract and citation database of peer-reviewed literature", category: "Research Database", url: "https://www.scopus.com", icon: "Database", active: true },
    { name: "JSTOR", description: "Digital library of academic journals, books, and primary sources", category: "E-Journal", url: "https://www.jstor.org", icon: "Newspaper", active: true },
    { name: "IEEE Xplore", description: "Engineering and technology literature from IEEE", category: "Research Database", url: "https://ieeexplore.ieee.org", icon: "Database", active: true },
    { name: "SpringerLink", description: "Scientific, technical and medical research from Springer", category: "E-Journal", url: "https://link.springer.com", icon: "Newspaper", active: true },
    { name: "PubMed Central", description: "Biomedical and life sciences journal literature archive", category: "Research Database", url: "https://www.ncbi.nlm.nih.gov/pmc", icon: "Database", active: true },
    { name: "Web of Science", description: "Citation indexing and research discovery platform", category: "Research Database", url: "https://www.webofscience.com", icon: "Database", active: true },
    { name: "EBSCOhost", description: "Multi-disciplinary full-text database platform", category: "E-Journal", url: "https://search.ebscohost.com", icon: "Newspaper", active: true },
    { name: "ProQuest", description: "Dissertations, theses, and scholarly content", category: "E-Book", url: "https://www.proquest.com", icon: "BookOpen", active: true },
  ];

  for (const res of resourcesData) {
    await db.digitalResource.create({ data: res });
  }
  console.log(`✅ ${resourcesData.length} digital resources seeded`);

  // 11. Seed site content
  const siteContent = [
    {
      section: "hero",
      content: JSON.stringify({
        badge: "Welcome to OSGU Central Library",
        title: "Your Gateway to Knowledge & Discovery",
        description: "Explore our vast collection of 50,000+ books, 500+ journals, digital resources, and research databases. Empowering education and research at OSGU.",
      }),
    },
    {
      section: "stats",
      content: JSON.stringify([
        { icon: "BookOpen", value: 50000, label: "Books & Volumes", suffix: "+" },
        { icon: "Newspaper", value: 500, label: "Journals & Periodicals", suffix: "+" },
        { icon: "Users", value: 10000, label: "Registered Members", suffix: "+" },
        { icon: "Monitor", value: 200, label: "E-Resources & Databases", suffix: "+" },
      ]),
    },
    {
      section: "announcements",
      content: JSON.stringify([
        { title: "Extended Hours During Exam Season", date: "Apr 10, 2025", icon: "Clock", color: "#C63134" },
        { title: "New Digital Archives: 1,000+ Rare Manuscripts", date: "Apr 8, 2025", icon: "Globe", color: "#0095EB" },
        { title: "Best Academic Library Award 2025", date: "Apr 5, 2025", icon: "Star", color: "#DBAA36" },
        { title: "Spring Book Fair: 2,500+ New Titles", date: "Apr 1, 2025", icon: "BookOpen", color: "#75B740" },
        { title: "Library Mobile App Launched", date: "Mar 25, 2025", icon: "Monitor", color: "#E98F10" },
      ]),
    },
    {
      section: "header",
      content: JSON.stringify({
        ticker: [
          "📚 New Arrivals: 2,500+ books added to our collection — Browse the Catalog now!",
          "📢 Admissions Open for 2025-26 — Visit the Admission Office for details",
          "🏆 OSGU Central Library wins \"Best Academic Library\" Award 2025",
          "⏰ Extended Hours: Library open until 11 PM during exam season",
          "📱 New OSGU Library Mobile App — Download now on Android & iOS"
        ],
        phone: "+91-12345-67890",
        email: "library@osgu.ac.in",
        libraryName: "CENTRAL LIBRARY",
        universityName: "Om Sterling Global University"
      }),
    },
    {
      section: "footer",
      content: JSON.stringify({
        description: "The OSGU Central Library is the heart of academic excellence, providing access to a vast collection of books, journals, digital resources, and research databases for the entire university community.",
        address: "OSGU Campus, NH-52, Village Brahmanwas, Distt. Hisar, Haryana - 125001",
        phone: "+91-12345-67890",
        email: "library@osgu.ac.in",
        hours: "Mon-Fri: 8:00 AM - 9:00 PM | Sat: 9:00 AM - 6:00 PM | Sun: 10:00 AM - 4:00 PM",
        copyright: "© 2025 OSGU Central Library, Om Sterling Global University. All rights reserved.",
        socialLinks: { facebook: "#", twitter: "#", instagram: "#", linkedin: "#", youtube: "#" }
      }),
    },
    {
      section: "about_page",
      content: JSON.stringify({
        mission: "To provide comprehensive library and information services that support the academic, research, and intellectual needs of the OSGU community.",
        vision: "To be a world-class academic library that fosters knowledge creation, innovation, and lifelong learning.",
        timeline: [
          { year: "2015", title: "Foundation", description: "OSGU Central Library established with 5,000 volumes." },
          { year: "2017", title: "Digital Transformation", description: "Launched digital library with e-books and online journals." },
          { year: "2018", title: "Research Support", description: "Added Scopus, Web of Science, and 20+ research databases." },
          { year: "2019", title: "Building Expansion", description: "Library expanded to 25,000 sq. ft. with new reading halls." },
          { year: "2020", title: "COVID Adaptation", description: "Launched virtual library services and remote access portal." },
          { year: "2021", title: "Smart Library", description: "Implemented RFID-based automated checkout system." },
          { year: "2022", title: "50,000 Volumes", description: "Collection reached 50,000+ books and 500+ journal subscriptions." },
          { year: "2023", title: "Innovation Hub", description: "Opened makerspace and multimedia production studio." },
          { year: "2024", title: "National Award", description: "Received 'Best Academic Library' award from NLA." }
        ],
        policies: [
          { title: "Borrowing Policy", description: "Students: 10 books for 14 days. Faculty: 20 books for 30 days. Renewal up to 2 times." },
          { title: "Overdue Policy", description: "Fine of Rs. 5 per day per book. Maximum fine Rs. 500." },
          { title: "Membership Policy", description: "OSGU students and faculty get free membership. Alumni: Rs. 500/year." },
          { title: "Library Conduct", description: "Maintain silence. No food/drinks. Mobile phones on silent." }
        ]
      }),
    },
    {
      section: "contact_page",
      content: JSON.stringify({
        address: "OSGU Campus, NH-52, Village Brahmanwas, Distt. Hisar, Haryana - 125001",
        phone: "+91-12345-67890",
        email: "library@osgu.ac.in",
        hours: [
          { day: "Monday - Friday", time: "8:00 AM - 9:00 PM" },
          { day: "Saturday", time: "9:00 AM - 6:00 PM" },
          { day: "Sunday", time: "10:00 AM - 4:00 PM" },
          { day: "Exam Season", time: "7:00 AM - 11:00 PM" },
          { day: "Holidays", time: "Closed" }
        ],
        departments: [
          { name: "Circulation Desk", phone: "+91-12345-67890", email: "circulation@osgu.ac.in" },
          { name: "Reference Section", phone: "+91-12345-67891", email: "reference@osgu.ac.in" },
          { name: "Digital Resources", phone: "+91-12345-67892", email: "digital@osgu.ac.in" },
          { name: "Technical Section", phone: "+91-12345-67893", email: "technical@osgu.ac.in" }
        ]
      }),
    },
    {
      section: "research_page",
      content: JSON.stringify({
        citationTools: [
          { name: "Zotero", description: "Free reference management tool for collecting, organizing, and sharing research.", url: "https://www.zotero.org" },
          { name: "Mendeley", description: "Academic reference manager and PDF organizer with collaboration features.", url: "https://www.mendeley.com" },
          { name: "EndNote", description: "Professional reference management for researchers and publishers.", url: "https://endnote.com" },
          { name: "Google Scholar", description: "Search engine for scholarly literature across all disciplines.", url: "https://scholar.google.com" }
        ],
        guides: [
          { title: "Getting Started with Library Research", type: "Beginner" },
          { title: "Advanced Database Searching", type: "Intermediate" },
          { title: "Systematic Review Methods", type: "Advanced" },
          { title: "Citation Styles (APA, MLA, Chicago)", type: "Beginner" },
          { title: "Plagiarism Prevention & Detection", type: "Beginner" }
        ]
      }),
    },
    {
      section: "kids_page",
      content: JSON.stringify({
        kidsCollections: [
          { title: "Picture Books", age: "3-6 years", count: "500+", color: "#C63134" },
          { title: "Early Readers", age: "5-7 years", count: "400+", color: "#0095EB" },
          { title: "Children's Fiction", age: "7-12 years", count: "800+", color: "#75B740" },
          { title: "Science & Nature", age: "6-12 years", count: "300+", color: "#DBAA36" }
        ],
        programs: [
          { title: "Summer Reading Challenge", age: "6-14 years", schedule: "May-July", color: "#C63134" },
          { title: "Story Time Saturdays", age: "3-8 years", schedule: "Every Saturday 10 AM", color: "#0095EB" },
          { title: "Science Explorers Club", age: "8-14 years", schedule: "Wednesdays 3 PM", color: "#75B740" }
        ]
      }),
    },
    {
      section: "account_page",
      content: JSON.stringify({
        welcomeTitle: "My Library Account",
        welcomeMessage: "Manage your borrowed books, reservations, and profile settings.",
        features: [
          { title: "View Borrowed Books", description: "See all books currently checked out with due dates." },
          { title: "Reserve Books", description: "Place reservations on unavailable books." },
          { title: "Renew Online", description: "Renew borrowed books from home." },
          { title: "Reading History", description: "View your past borrowed books." },
          { title: "Fine Payment", description: "Check and pay outstanding library fines." },
          { title: "Profile Settings", description: "Update contact information and preferences." }
        ]
      }),
    },
  ];

  for (const sc of siteContent) {
    await db.siteContent.upsert({
      where: { section: sc.section },
      update: { content: sc.content },
      create: sc,
    });
  }
  console.log(`✅ ${siteContent.length} site content sections seeded`);

  console.log("\n🎉 Seeding complete!");
}

main()
  .catch((e) => {
    console.error("❌ Seeding failed:", e);
    process.exit(1);
  })
  .finally(async () => {
    await db.$disconnect();
  });
